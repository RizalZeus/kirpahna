#!/bin/bash
# Null Panel - Terminal APK Builder
# Usage: ./build.sh <project.zip> [output_dir]

set -e

GRADLE_HOME="/root/gradle-8.10.2"
ANDROID_HOME="/root/android-sdk"
JAVA_HOME="/usr/lib/jvm/java-21-openjdk-amd64"
BUILD_DIR="/root/null-builder/builds"
PROJECTS_DIR="/root/null-builder/projects"
SERVER_IP="198.105.115.183"
SERVER_PORT="6969"

export ANDROID_HOME JAVA_HOME

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_status() {
    echo -e "${BLUE}[BUILD]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[OK]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

# Check input
if [ -z "$1" ]; then
    print_error "Usage: $0 <project.zip> [output_dir]"
    exit 1
fi

ZIP_FILE="$1"
OUTPUT_DIR="${2:-$BUILD_DIR}"

if [ ! -f "$ZIP_FILE" ]; then
    print_error "File not found: $ZIP_FILE"
    exit 1
fi

BUILD_ID="build_$(date +%s)"
PROJECT_DIR="$PROJECTS_DIR/$BUILD_ID"
OUTPUT_APK="$OUTPUT_DIR/${BUILD_ID}.apk"

mkdir -p "$PROJECT_DIR" "$OUTPUT_DIR"

echo ""
echo "=============================="
echo "  Null Panel - APK Builder"
echo "=============================="
echo ""

# Step 1: Extract
print_status "Extracting project..."
unzip -q -o "$ZIP_FILE" -d "$PROJECT_DIR"
FILE_COUNT=$(find "$PROJECT_DIR" -type f | wc -l)
print_success "Extracted $FILE_COUNT files"

# Step 2: Find project root
print_status "Finding project root..."
PROJECT_ROOT=""
while IFS= read -r -d '' gradle_file; do
    PROJECT_ROOT="$(dirname "$gradle_file")"
    break
done < <(find "$PROJECT_DIR" -name "build.gradle" -o -name "build.gradle.kts" -print0 2>/dev/null)

if [ -z "$PROJECT_ROOT" ]; then
    print_error "build.gradle not found! Not a valid Android/Gradle project."
    rm -rf "$PROJECT_DIR"
    exit 1
fi
print_success "Project root: $PROJECT_ROOT"

# Step 3: Auto-patch URLs
print_status "Patching server URLs..."
PATCHED=0
while IFS= read -r -d '' file; do
    if grep -q "127.0.0.1:8080\|localhost:8080" "$file" 2>/dev/null; then
        sed -i "s/127.0.0.1:8080/${SERVER_IP}:${SERVER_PORT}/g" "$file"
        sed -i "s/localhost:8080/${SERVER_IP}:${SERVER_PORT}/g" "$file"
        PATCHED=$((PATCHED + 1))
    fi
done < <(find "$PROJECT_ROOT" -type f \( -name "*.java" -o -name "*.kt" -o -name "*.xml" -o -name "*.json" -o -name "*.properties" \) -print0 2>/dev/null)
print_success "Patched $PATCHED file(s) -> ${SERVER_IP}:${SERVER_PORT}"

# Step 4: Build
print_status "Starting Gradle build..."
print_warn "This may take a few minutes..."

cd "$PROJECT_ROOT"
if "$GRADLE_HOME/bin/gradle" assembleRelease --no-daemon --stacktrace 2>&1; then
    print_success "Build completed!"
else
    print_error "Build failed! Check the Gradle output above."
    exit 1
fi

# Step 5: Find APK
print_status "Locating APK..."
APK_PATH=""
for candidate in \
    "$PROJECT_ROOT/app/build/outputs/apk/release/app-release.apk" \
    "$PROJECT_ROOT/app/build/outputs/apk/release/app-release-unsigned.apk"; do
    if [ -f "$candidate" ]; then
        APK_PATH="$candidate"
        break
    fi
done

if [ -z "$APK_PATH" ]; then
    APK_PATH=$(find "$PROJECT_ROOT" -name "*.apk" -type f 2>/dev/null | head -1)
fi

if [ -z "$APK_PATH" ]; then
    print_error "APK not found in build output!"
    exit 1
fi

cp "$APK_PATH" "$OUTPUT_APK"
APK_SIZE=$(du -h "$OUTPUT_APK" | cut -f1)

# Cleanup
rm -rf "$PROJECT_DIR"

echo ""
echo "=============================="
print_success "Build Complete!"
echo "=============================="
echo ""
echo "  APK: $OUTPUT_APK"
echo "  Size: $APK_SIZE"
echo "  Server: ${SERVER_IP}:${SERVER_PORT}"
echo ""
