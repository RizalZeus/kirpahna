package com.drnull.app;

import android.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class CryptoHelper {

    private static final String KP1 = "__KP1__";
    private static final String KP2 = "__KP2__";
    private static final String KP3 = "__KP3__";
    private static final String KP4 = "__KP4__";
    private static final String IV_B64 = "__IV__";
    private static final String XOR_B64 = "__XOR__";

    private static byte[] dec(String s) {
        try { return Base64.decode(s, Base64.NO_WRAP); }
        catch (Exception e) { return new byte[0]; }
    }

    private static byte[] buildKey() {
        byte[] p1 = dec(KP1), p2 = dec(KP2), p3 = dec(KP3), p4 = dec(KP4);
        byte[] xm = dec(XOR_B64);
        byte[] key = new byte[32];
        int o = 0;
        for (int i = 0; i < p1.length && o < 32; i++) key[o++] = p1[i];
        for (int i = 0; i < p2.length && o < 32; i++) key[o++] = p2[i];
        for (int i = 0; i < p3.length && o < 32; i++) key[o++] = p3[i];
        for (int i = 0; i < p4.length && o < 32; i++) key[o++] = p4[i];
        for (int i = 0; i < 32; i++) key[i] ^= xm[i % xm.length];
        return key;
    }

    public static String decrypt(String enc) {
        try {
            byte[] key = buildKey();
            byte[] iv = dec(IV_B64);
            byte[] data = Base64.decode(enc, Base64.NO_WRAP);
            SecretKeySpec ks = new SecretKeySpec(key, "AES");
            IvParameterSpec ivs = new IvParameterSpec(iv);
            Cipher c = Cipher.getInstance("AES/CBC/PKCS5Padding");
            c.init(Cipher.DECRYPT_MODE, ks, ivs);
            return new String(c.doFinal(data), "UTF-8");
        } catch (Exception e) {
            return "";
        }
    }
}
