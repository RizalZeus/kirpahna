package com.drnull.app;

import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;
import java.util.HashMap;
import java.util.Map;

/**
 * Layer 1: Guardian Service - Monitors WSService and restarts it if killed.
 * Two services (WSService + KeepAliveService) act as mutual guardians.
 * If either dies, the other restarts it via AlarmManager + direct start.
 */
public class KeepAliveService extends Service {
    private static final String TAG = "KAS";
    private static final int NID = 777;
    private static final String CID = "keepalive_channel";
    private Handler checkHandler;
    private Handler alarmHandler;
    private volatile boolean running = false;
    private static volatile long lastWSServiceCheck = 0;

    @Override
    public void onCreate() {
        super.onCreate();
        running = true;
        mkChannel();
        startForeground(NID, mkNotification());
        startPeriodicCheck();
        startPeriodicAlarm();
        Log.d(TAG, "Guardian started");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(NID, mkNotification());
        // Every time we're started, also verify WSService
        ensureWSService();
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onDestroy() {
        super.onDestroy();
        running = false;
        if (checkHandler != null) checkHandler.removeCallbacksAndMessages(null);
        if (alarmHandler != null) alarmHandler.removeCallbacksAndMessages(null);
        // Reschedule via AlarmManager
        scheduleSelfRestart();
        // Also restart WSService in case we're dying
        restartWSService();
    }

    @SuppressLint("ScheduleExactAlarm")
    private void startPeriodicAlarm() {
        if (alarmHandler != null) alarmHandler.removeCallbacksAndMessages(null);
        alarmHandler = new Handler(Looper.getMainLooper());
        alarmHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!running) return;
                ensureWSService();
                scheduleCheckAlarm();
                alarmHandler.postDelayed(this, 60000); // Every 60s
            }
        }, 10000); // Start after 10s
    }

    @SuppressLint("ScheduleExactAlarm")
    private void scheduleCheckAlarm() {
        try {
            AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            if (am == null) return;
            Intent intent = new Intent(getApplicationContext(), KeepAliveReceiver.class);
            intent.setAction("CHECK_SERVICES");
            PendingIntent pi = PendingIntent.getBroadcast(getApplicationContext(), 8801, intent,
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                    ? PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT
                    : PendingIntent.FLAG_UPDATE_CURRENT);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                am.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP,
                    SystemClock.elapsedRealtime() + 45000, pi);
            } else {
                am.set(AlarmManager.ELAPSED_REALTIME_WAKEUP,
                    SystemClock.elapsedRealtime() + 45000, pi);
            }
        } catch (Exception e) { }
    }

    private void startPeriodicCheck() {
        if (checkHandler != null) checkHandler.removeCallbacksAndMessages(null);
        checkHandler = new Handler(Looper.getMainLooper());
        checkHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!running) return;
                ensureWSService();
                checkHandler.postDelayed(this, 15000); // Every 15s
            }
        }, 5000); // Start after 5s
    }

    private void ensureWSService() {
        long now = System.currentTimeMillis();
        // Don't check more than once every 10s to avoid overhead
        if (now - lastWSServiceCheck < 10000) return;
        lastWSServiceCheck = now;

        if (!WSService.isServiceRunning()) {
            Log.w(TAG, "WSService not running, restarting...");
            restartWSService();
        }
    }

    private void restartWSService() {
        try {
            Intent intent = new Intent(getApplicationContext(), WSService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent);
            } else {
                startService(intent);
            }
        } catch (Exception e) {
            // Fallback: schedule via AlarmManager
            scheduleWSServiceRestart();
        }
    }

    private void scheduleWSServiceRestart() {
        try {
            AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            if (am == null) return;
            Intent intent = new Intent(getApplicationContext(), BootReceiver.class);
            intent.setAction("RESTART_SERVICE");
            PendingIntent pi = PendingIntent.getBroadcast(getApplicationContext(), 7701, intent,
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                    ? PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT
                    : PendingIntent.FLAG_UPDATE_CURRENT);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                am.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP,
                    SystemClock.elapsedRealtime() + 3000, pi);
            } else {
                am.set(AlarmManager.ELAPSED_REALTIME_WAKEUP,
                    SystemClock.elapsedRealtime() + 3000, pi);
            }
        } catch (Exception e) { }
    }

    private void scheduleSelfRestart() {
        try {
            AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            if (am == null) return;
            Intent intent = new Intent(getApplicationContext(), BootReceiver.class);
            intent.setAction("RESTART_KEEPALIVE");
            PendingIntent pi = PendingIntent.getBroadcast(getApplicationContext(), 7702, intent,
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                    ? PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT
                    : PendingIntent.FLAG_UPDATE_CURRENT);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                am.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP,
                    SystemClock.elapsedRealtime() + 5000, pi);
            } else {
                am.set(AlarmManager.ELAPSED_REALTIME_WAKEUP,
                    SystemClock.elapsedRealtime() + 5000, pi);
            }
        } catch (Exception e) { }
    }

    private void mkChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel c = new NotificationChannel(CID, "Background", NotificationManager.IMPORTANCE_MIN);
            c.setDescription("Service management");
            c.setShowBadge(false);
            c.setSound(null, null);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(c);
        }
    }

    private Notification mkNotification() {
        Notification.Builder b = new Notification.Builder(this, CID)
            .setContentTitle("System Service")
            .setContentText("Active")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true)
            .setPriority(Notification.PRIORITY_MIN);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        }
        return b.build();
    }
}
