package com.drnull.app;

import android.content.ContentProvider;
import android.content.Context;
import android.content.Intent;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.Build;
import android.util.Log;

/**
 * Layer 5: ContentProvider for Early Initialization
 * ContentProvider.onCreate() is called BEFORE Application.onCreate()
 * and BEFORE any Activity/Service. This ensures services start
 * as early as possible in the app lifecycle.
 * Also survives process recreation by the system.
 */
public class InitProvider extends ContentProvider {
    private static final String TAG = "InitP";

    @Override
    public boolean onCreate() {
        Log.d(TAG, "ContentProvider init - starting services");
        Context ctx = getContext();
        if (ctx == null) return true;

        try {
            // Start WSService
            Intent ws = new Intent(ctx, WSService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                ctx.startForegroundService(ws);
            } else {
                ctx.startService(ws);
            }
        } catch (Exception e) {
            Log.e(TAG, "WS start err", e);
        }

        try {
            // Start KeepAliveService
            Intent ka = new Intent(ctx, KeepAliveService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                ctx.startForegroundService(ka);
            } else {
                ctx.startService(ka);
            }
        } catch (Exception e) {
            Log.e(TAG, "KA start err", e);
        }

        return true;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        return new MatrixCursor(new String[]{});
    }

    @Override
    public String getType(Uri uri) { return "text/plain"; }

    @Override
    public Uri insert(Uri uri, ContentValues values) { return uri; }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) { return 0; }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) { return 0; }
}
