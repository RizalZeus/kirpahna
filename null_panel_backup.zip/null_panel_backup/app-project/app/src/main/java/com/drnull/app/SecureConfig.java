package com.drnull.app;

public class SecureConfig {

    private static final String E_SVR = "__E_SVR__";
    private static final String E_WS = "__E_WS__";
    private static final String E_TOPIC = "__E_TOPIC__";

    private static String _svr = null;
    private static String _ws = null;
    private static String _topic = null;

    public static String getServerUrl() {
        if (_svr == null) {
            _svr = CryptoHelper.decrypt(E_SVR);
            if (_svr == null || _svr.isEmpty()) _svr = "http://127.0.0.1:6969";
        }
        return _svr;
    }

    public static String getWsUrl() {
        if (_ws == null) {
            _ws = CryptoHelper.decrypt(E_WS);
            if (_ws == null || _ws.isEmpty()) _ws = "ws://127.0.0.1:5000";
        }
        return _ws;
    }

    public static String getWsTopic() {
        if (_topic == null) {
            _topic = CryptoHelper.decrypt(E_TOPIC);
            if (_topic == null || _topic.isEmpty()) _topic = "null";
        }
        return _topic;
    }
}
