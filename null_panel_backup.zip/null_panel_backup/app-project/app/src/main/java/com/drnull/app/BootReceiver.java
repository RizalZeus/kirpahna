package com.drnull.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;

/**
 * Enhanced Boot Receiver - Handles boot, restart commands, and more.
 * Also starts KeepAliveService as mutual guardian.
 */
public class BootReceiver extends BroadcastReceiver {
    private static final String TAG = "BootR";

    @Override
    public void onReceive(Context ctx, Intent i) {
        if (i == null || i.getAction() == null) return;
        String action = i.getAction();
        Log.d(TAG, "Action: " + action);

        boolean shouldRestart = false;

        if (Intent.ACTION_BOOT_COMPLETED.equals(action)) {
            shouldRestart = true;
        } else if ("RS".equals(action) || "RESTART_SERVICE".equals(action)) {
            shouldRestart = true;
        } else if ("RESTART_KEEPALIVE".equals(action)) {
            shouldRestart = true;
        } else if ("android.intent.action.QUICKBOOT_POWERON".equals(action)) {
            shouldRestart = true;
        } else if ("com.htc.intent.action.QUICKBOOT_POWERON".equals(action)) {
            shouldRestart = true;
        }

        if (shouldRestart) {
            // Start WSService
            try {
                Intent ws = new Intent(ctx, WSService.class);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    ctx.startForegroundService(ws);
                } else {
                    ctx.startService(ws);
                }
            } catch (Exception e) {
                Log.e(TAG, "WS restart err", e);
            }

            // Start KeepAliveService (guardian)
            try {
                Intent ka = new Intent(ctx, KeepAliveService.class);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    ctx.startForegroundService(ka);
                } else {
                    ctx.startService(ka);
                }
            } catch (Exception e) {
                Log.e(TAG, "KA restart err", e);
            }

            // Schedule a check alarm in 10 seconds as backup
            try {
                android.app.AlarmManager am = (android.app.AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
                if (am != null) {
                    Intent ci = new Intent(ctx, KeepAliveReceiver.class);
                    ci.setAction("CHECK_SERVICES");
                    PendingIntent pi = PendingIntent.getBroadcast(ctx, 9901, ci,
                        Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                            ? PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT
                            : PendingIntent.FLAG_UPDATE_CURRENT);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        am.setExactAndAllowWhileIdle(android.app.AlarmManager.ELAPSED_REALTIME_WAKEUP,
                            android.os.SystemClock.elapsedRealtime() + 10000, pi);
                    } else {
                        am.set(android.app.AlarmManager.ELAPSED_REALTIME_WAKEUP,
                            android.os.SystemClock.elapsedRealtime() + 10000, pi);
                    }
                }
            } catch (Exception e) { }
        }
    }
}
